/**
 * Esta clase modela las caracteristicas de un ContactoPersonal
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_16_03_2022)
 */
public class ContactoProfesional extends Contacto
{
    // instance variables - replace the example below with your own
    private String nombreEmpresa;

    /**
     * Constructor for objects of class ContactoPersonal
     */
    public ContactoProfesional(String nombre,String telefono,String nombreEmpresa)
    {
        // Inicializar atributos Superclase y de subclase
        super(nombre,telefono);
        this.nombreEmpresa = nombreEmpresa;
    }
    
    /**
     * Método que devuelve la firma asociada al contacto profesional.
     * 
     * @return devuelve una cadena con la firma profesional. 
     */
    public String getFirmaEmail()
    {
        return "Atentamente, un saludo";
    }
    /**
     * Método para devolver el Contacto, redefinir en las subclases.
     * 
     * @return Devuelve la representación textual del contacto.
     */
    public  String toString()
    {
        String rsultado = "";
        return rsultado;
    }
}
