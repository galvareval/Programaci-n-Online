/**
 * Clase que represnta una interfaz
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_16_03_2022)
 */
public interface Visualizable
{
    public void mostrar();
}
