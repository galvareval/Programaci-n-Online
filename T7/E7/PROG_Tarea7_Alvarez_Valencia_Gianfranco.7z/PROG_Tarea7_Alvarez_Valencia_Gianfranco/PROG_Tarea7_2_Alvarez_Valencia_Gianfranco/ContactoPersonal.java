import java.util.GregorianCalendar;
import java.util.Calendar;

/**
 * Esta clase modela las caracteristicas de un ContactoPersonal
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_16_03_2022)
 */
public class ContactoPersonal extends Contacto
{
    // instance variables - replace the example below with your own
    private Fecha fechaNacimiento;

    /**
     * Constructor for objects of class ContactoPersonal
     */
    public ContactoPersonal(String nombre,String telefono,Fecha fechaNacimiento)
    {
        // Inicializar atributos Superclase y de subclase
        super(nombre,telefono);
        this.fechaNacimiento = fechaNacimiento;
        
    }
    
    /**
     * Método que devuelve la firma asociada al contacto personal.
     * 
     * @return devuelve una cadena con la firma personal
     */
    public String getFirmaEmail()
    {
        return "Con cariño, adiós";
    }
    
    /**
     * Método que devuelve un booleano true si es el cumpleaños del contacto.
     * 
     * @return Devuelve un booleano true si es el cumpleaños del contacto.
     */
    public boolean esCumpleaños()
    {
        // Resultado
        boolean resultado = false;
        // obtener fecha actual
        Calendar fechaHoy = new GregorianCalendar();
        int mes = fechaHoy.get(Calendar.MONTH);
        int dia = fechaHoy.get(Calendar.DAY_OF_MONTH);
        // Comparar fecha actual con la de nacimiento.
        if(fechaNacimiento.getDia() == dia && fechaNacimiento.getMes() == mes)
            resultado = true;
        return resultado;
    }
    
    /**
     * Método que devuelve al fecha de nacimiento.
     * 
     * @return devuelve la fecha de nacimineto.
     */
    public Fecha getfechaNacimiento()
    {
        return fechaNacimiento;
    }
    
    /**
     * Método que sirve para modificar la fecha de nacimineto.
     * 
     * @param nuevaFecha para pasar la nueva fecha de nacimiento.
     */
    public void setfechaNacimiento(Fecha nuevafechaNacimiento)
    {
         fechaNacimiento = nuevafechaNacimiento;
    }
    
    /**
     * Método para devolver el Contacto, redefinir en las subclases.
     * 
     * @return Devuelve la representación textual del contacto.
     */
    public String toString()
    {
        String rsultado = "";
        rsultado += "Nombre : " + super.getNombre() + "\nTeléfono: " + super.getTelefono() + getClass().getSimpleName() + "fecha nac";
        return rsultado;
    }
}
