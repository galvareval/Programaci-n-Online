import java.util.Objects;
/**
 * Esta clase modela las caracteristicas de un Contacto
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_16_03_2022)
 */
public abstract class  Contacto
{
    // Atributos
    private String nombre;
    private String telefono;
    private String firma;

    /**
     * Constructor para la calse Contacto
     */
    public Contacto(String nombre,String telefono)
    {
        // Inicializar atributos
        this.nombre = nombre;
        this.telefono = telefono;
        this.firma = getFirmaEmail();
    }
    
    /**
     * Método para obtener el nombre del contacto
     * 
     * @return Devuelve el nombre del contacto
     */
    public String getNombre()
    {
        return nombre;
    }
    
    /**
     * Método para obtener el telefono del contacto
     * 
     * @return Devuelve el telefono del contacto
     */
    public String getTelefono()
    {
        return telefono;
    }
    
    /**
     * Método para obtener la firma del contacto
     * 
     * @return Devuelve la firma del contacto
     */
    public String getFirma()
    {
        return firma;
    }    
    
    /**
     * Redefinición del método hashCode(), que devuelve el código hash del atributo.
     * 
     * @return Devuelve el código hash del atributo número.
     */
    public int hashCode()
    {
        int hash = 9;
        hash = 49 * hash + Objects.hashCode(this.nombre);
        return hash;
    }
    
    /**
     * Redefinición del método equals() para comparar si dos contactos son iguales.
     * 
     * @param obj objeto a comparar
     * @return Devuelve un booleano con el resultado de la comparación.
     */
    public boolean equals(Object obj)
    {
        if (obj instanceof Contacto) 
        {
            //Cast del objeto parámetro.
            Contacto tmpContacto = (Contacto) obj;
            //Son iguales si tienen el mismo nombre y telefono y ademas el mismo tipo de contacto
            if ((this.nombre.equals(tmpContacto.nombre)) && this.telefono.equals(tmpContacto.telefono) && (this.getClass() == tmpContacto.getClass()))
            { 
                return true;
            } 
            else 
            { 
                return false; 
            }
        } 
        else
        { 
            return false;
        }
    }
    
    /**
     * Método para comparar contactos por su nombre.
     * 
     * @param conAcomparar Para pasar el contacto a comparar.
     * @return Devuelve un entero con el resutlado de la comparación.
     */
    public int compareTo(Contacto conAcomparar)
    {
        if(this.nombre.length() == conAcomparar.nombre.length())
            return 0;
        else if (this.nombre.length() < conAcomparar.nombre.length())
            return -1;
        else
            return 1;
    }
    
    /**
     * Método que devuelve la primera letra del nombere.
     * 
     * @return Devuelve la primera letra del nombre.
     */
    public String getPrimeraLetra()
    {
        return String.valueOf(nombre.charAt(0));
    }
    
    /**
     * Método 
     */
    public abstract String getFirmaEmail();
    
    /**
     * Método para devolver el Contacto, redefinir en las subclases.
     * 
     * @return Devuelve la representación textual del contacto.
     */
    public abstract String toString();
}
