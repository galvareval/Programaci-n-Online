import java.util.*;
import java.util.TreeMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Arrays;

/**
 * Esta clase representa a través de un map los contactos existentes.
 * la clave (ABCdario) y su ArrayList de contactos asociado a la letra.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_16_03_2022)
 */
public class AgendaContactos implements Visualizable
{
    // Atributos
    TreeMap<String, ArrayList<Contacto>> agenda;
    //private ArrayList<Contacto> AgendaA;
    
    /**
     * Constructor for objects of class AgendaContactos
     */
    public AgendaContactos()
    {
        // Crear el Map
        agenda = new TreeMap<String, ArrayList<Contacto>>();
        // Inicializar el map
        inicializar();
    }
    
    /**
     * Método para inicializar las claves el map.
     */
    private void inicializar()
    {
        //Inicializar las claves con el alfabeto y su valor a null.
        agenda.put("A", new ArrayList<Contacto>());
        agenda.put("B", new ArrayList<Contacto>());
        agenda.put("C", new ArrayList<Contacto>());
        agenda.put("D", new ArrayList<Contacto>());
        agenda.put("E", new ArrayList<Contacto>());
        agenda.put("F", new ArrayList<Contacto>());
        agenda.put("G", new ArrayList<Contacto>());
        agenda.put("H", new ArrayList<Contacto>());
        agenda.put("I", new ArrayList<Contacto>());
        agenda.put("J", new ArrayList<Contacto>());
        agenda.put("K", new ArrayList<Contacto>());
        agenda.put("L", new ArrayList<Contacto>());
        agenda.put("M", new ArrayList<Contacto>());
        agenda.put("N", new ArrayList<Contacto>());
        agenda.put("O", new ArrayList<Contacto>());
        agenda.put("P", new ArrayList<Contacto>());
        agenda.put("Q", new ArrayList<Contacto>());
        agenda.put("R", new ArrayList<Contacto>());
        agenda.put("S", new ArrayList<Contacto>());
        agenda.put("T", new ArrayList<Contacto>());
        agenda.put("U", new ArrayList<Contacto>());
        agenda.put("V", new ArrayList<Contacto>());
        agenda.put("W", new ArrayList<Contacto>());
        agenda.put("X", new ArrayList<Contacto>());
        agenda.put("Y", new ArrayList<Contacto>());
        agenda.put("Z", new ArrayList<Contacto>());
    }
    
    /**
     * Método que añade el contacto a la agenda en la letra correspondiente.
     * 
     * @param contacto Para pasar el contacto a añdir en la agenda. 
     */
    public void añadirContacto(Contacto contacto)
    {
        // conocer la letra para meter al map
        String letra =  contacto.getPrimeraLetra();
        // para guardar el Valor anterior del mapa
        ArrayList<Contacto> old = new ArrayList<Contacto>();
        old = agenda.get(letra);//Devuelve array lsit en la key letra
        if (hayValores(old) == false)//Si en la lista asociada a la letra no hay nada.
        {
            old.add(contacto);//Añadir a la lista el contacto.
            agenda.put(letra,(old));//Actualizar la lista en el map
        }
        else// Hay valores, comprobar si ya existe el contacto en la lista asociada a la letra
        {
            if(existeContacto(old, contacto) == false)
            {
                old.add(contacto);//Añadir a la lista el contacto.
                agenda.put(letra,(old));//Actualizar la lista en el map
            }
        }
    }
    
    /**
     * Método para comprobar si un contacto existe en una lista.
     * 
     * @param Lista Para pasar la lista en que se buscara el contacto.
     * @param contacto Para pasar el contacto que se buscará en la lista.
     * 
     * @retun devuevle booleano, true si lo ha encontrado.
     */
    private boolean existeContacto(ArrayList<Contacto> lista, Contacto contacto)
    {
         // Declarar iterador
        Iterator<Contacto> it;
        it = lista.iterator();
        // Para saber si esta en la lista.
        boolean estaEnLaLista = false;//Empezar en false 
        // Comprobar contacto corrrecto.
        // Recorrer la lista mediante el iterador,
        while(it.hasNext())
        {
            Contacto con = it.next();
            // si esta en la lista el booleano estaEnLaLista a true
            if(con.equals(contacto) == true)
            {
                estaEnLaLista = true;
            }
        }
        return estaEnLaLista;
    }
    
    /**
     * Método que localizar los contactos de un contacto dado un nombre.
     * 
     * @param nombre Para pasar el nombre a buscar
     * @return Devuelve una lista con los contactos el contacto.
     */
    public ArrayList<Contacto> buscarContacto(String nombre)
    {
        // para guardar el Valor anterior del mapa
        ArrayList<Contacto> old = new ArrayList<Contacto>();
        old = agenda.get(String.valueOf(nombre.charAt(0)));// Contactos en la lista de la primera letra del nombre.
        // Para devolver el resultado.
        ArrayList<Contacto> resultado = new ArrayList<Contacto>();
        // Declarar iterador
        Iterator<Contacto> it;
        it = old.iterator();
        while(it.hasNext())
        {
            Contacto con = it.next();
            // si esl nombre de un contacto de la lista coincide con el del parámetro->meter a la lista resultado.
            if(con.getNombre().equals(nombre) == true)
            {
                resultado.add(con);
            }
        }
        return resultado;
    }
    
    /**
     * Método que localiza la lista de contactos(ArrayList asociado a la letra) en la que aparece un contacto.
     * 
     * @param contacto Para pasar el contacto a buscar
     * @return Devuelve la lista con los contactos de ese contacto.
     */
    public ArrayList<Contacto> buscarContacto(Contacto contacto)
    {
        String letra =  contacto.getPrimeraLetra();// Saber la key del map
        ArrayList<Contacto> resultado = new ArrayList<Contacto>();
        resultado = agenda.get(letra);// Contactos en la lista de la primera letra del nombre.
        return resultado;
    }
    
    /**
     * Método que sirve para borrar un contacto
     * 
     * @param contacto Para pasar el contacto a borrar.
     */
    public void borrarContacto(Contacto contacto)
    {
        ArrayList<Contacto> old = new ArrayList<Contacto>();//Almacenar valor viejo de la key
        String letra = contacto.getPrimeraLetra();// Saber la key del map
        old = buscarContacto(contacto);
        if(hayValores(old) == true)//hay valores en la lista, el contacto existe
        {
            // Declarar iterador
            Iterator<Contacto> it;
            it = old.iterator();
            while(it.hasNext())
            {
                Contacto con = it.next();
                // si el nombre de un contacto de la lista coincide con el del parámetro->borrarlo de la lista.
                if(con.equals(contacto) == true)
                {
                    old.remove(con);
                }
            }
            //Actualizar el array list en el map en la key
            agenda.put(letra,(old));//Actualizar la lista en el map
        }
    }
    
    /**
     * Método Devuelve un listado de contactos personales a los que hay que felicitar, es su cumpleaños.
     * 
     * @return Devuelve la lista con los contactos a felicitar.
     */
    public ArrayList<ContactoPersonal> felicitar()
    {
        // Para devolver el resultado.
        ArrayList<ContactoPersonal> resultado = new ArrayList<ContactoPersonal>();
        // Iterar el map para conseguir los Arraylist de todas las letras
        for(Map.Entry<String ,ArrayList<Contacto>> ag: agenda.entrySet())
        {
            //Add al ArrayList resultado los contactos personales que cumplen años en la letra del mapa.
            resultado.addAll(localizarCumpleaños(ag.getValue(),ag.getKey()));
            
        }
        return resultado;
    }
    
    /**
     * Método que dada la lista de contactos de una letra devuelve los contactos personales que cumplen años hoy.

     * @param lista Para pasar la lista de contactos.
     * @return Devuelve la lista con los contactotos personales a felicitar.
     */
    public ArrayList<ContactoPersonal> localizarCumpleaños(ArrayList<Contacto> listaLetra, String contactosLetra)//uso de letra?
    {
        // Para devolver el resultado.
        ArrayList<ContactoPersonal> resultado = new ArrayList<ContactoPersonal>();
        // Declarar iterador
        Iterator<Contacto> it;
        it = listaLetra.iterator();
        //obtener la fecha de hoy
        while(it.hasNext())
            {
                Contacto con = it.next();
                // comprobar que sea contacto(personal)
                if (con instanceof ContactoPersonal)
                {
                    // Si lo es hacer cast explícito 
                    ContactoPersonal conP = (ContactoPersonal) con;
                    if(conP.getClass().getSimpleName() == "ContactoPersonal")
                    {
                        //Si es su cumpleaños-> añadir al ArrayList
                        if (conP.esCumpleaños() == true)
                            resultado.add(conP);
                    }
                }
            }
        return resultado;
    }
    
    /**
     * Método que dada una lista de contactos indica si está vacia o no.
     * 
     * @param lista Para pasar la lista de contactos.
     */
    private boolean hayValores(ArrayList<Contacto> lista)
    {
        return lista.size() > 0;
    }
    
    /**
     * Método para la representación textual de la agenda.
     * 
     * @return Devuelve la representación textual de la agenda.
     */
    public String toString()
    {
        // Para almacenar el resultado.
        String resultado = "Agenda de contactos";
        // Para interar el ArrayList devuelto de la letra.
        ArrayList<Contacto> aux = new ArrayList<Contacto>();
        // Iterar el map.
        for(Map.Entry<String ,ArrayList<Contacto>> ag: agenda.entrySet())
        {
            if (hayValores(ag.getValue()) == true)
            {
                resultado += "\n" + ag.getKey() + "\n";
                // ArrayList de contactos de la letra
                aux = ag.getValue();
                // Declarar iterador
                Iterator<Contacto> it;
                it = aux.iterator();
                while(it.hasNext())
                {
                    Contacto con = it.next();
                    // Añadir a resultado el String de la representacion de cada contacto.
                    resultado += "\n\t" + con.toString();
                }        
            }
        }    
        return resultado;
    }
    
    /**
     * Método que devuelve el total de contactos que hay en la agenda
     * 
     * @return Devuelve el total de contactos que hay en la agenda.
     */
    public int totalContactos()
    {
        // Para guardar el ArrayList devuelto de la letra.
        ArrayList<Contacto> aux = new ArrayList<Contacto>();
        int contadorContactos = 0;
        // Iterar el map.
        for(Map.Entry<String ,ArrayList<Contacto>> ag: agenda.entrySet())
        {
            aux = ag.getValue();
            contadorContactos += aux.size();            
        }
        return contadorContactos;
    }
    
    /**
     * Método que devuelve el total de contactos personales que hay en la agenda.
     * 
     * @return Devuelve el nº de contactos personales en la agenda.
     */
    public int totalContactosPersonales()
    {
        // Para guardar el ArrayList devuelto de la letra.
        ArrayList<Contacto> aux = new ArrayList<Contacto>();
        int contadorContactosPersonales = 0;
        
        for(Map.Entry<String ,ArrayList<Contacto>> ag: agenda.entrySet())
        {
            aux = ag.getValue();
            // Declarar iterador
            Iterator<Contacto> it;
            it = aux.iterator();
            while(it.hasNext())
            {
                Contacto con = it.next();
                // Si es conctactopersonal
                if (con instanceof ContactoPersonal)
                {
                    // Si lo es hacer cast explícito 
                    ContactoPersonal conP = (ContactoPersonal) con;
                    if(conP.getClass().getSimpleName() == "ContactoPersonal")
                    {
                        contadorContactosPersonales++;
                    }
                }
            }
        }
        return contadorContactosPersonales;
    }
    
    /**
     * Método que devuelve un array con los contactos personales ordenados alfabéticamente en
     * la letra indicada.
     * 
     * @param letra letra de la agenda.
     * @return Devuelve un array de contactos de la letra indicada.
     */
    public Contacto[] contatctosPersonalesEn(char letra)
    {
        String sLetra = String.valueOf(letra);
        //Arrray resultado
        Contacto[] resul;
        // Para guardar el ArrayList devuelto de la letra.
        ArrayList<Contacto> aux = new ArrayList<Contacto>();
        aux = agenda.get(letra);
        // Para guardar el resultado
        ArrayList<Contacto> resultado = new ArrayList<Contacto>();
        // Declarar iterador
        Iterator<Contacto> it;
        it = aux.iterator();
        while(it.hasNext())
        {
            Contacto con = it.next();
            // Si es conctactopersonal
            if (con instanceof ContactoPersonal)
            {
                // Si lo es hacer cast explícito 
                ContactoPersonal conP = (ContactoPersonal) con;
                if(conP.getClass().getSimpleName() == "ContactoPersonal")
                {
                    resultado.add(conP);
                    
                }
            }
        }
        // Ordenar ArrayList
        //Collections.sort(resultado);
        /// pasar ArrayList a array
        resul = resultado.toArray(new Contacto [resultado.size()]);
        return resul;
    }
    /**
     * Método que sirve para mostrar por pantalla la agenda.
     */
    public void mostrar()
    {
        // String rsultado
        String resultado = "";
        resultado += toString();
        //Imprimir
        System.out.println(resultado);
    }
    
}
