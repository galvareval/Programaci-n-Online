import java.util.Objects;
/**
 * Esta clase representa a una fecha formada por día, mes y año.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_16_03_2022)
 */
public class Fecha
{
    // Atributos
    private int dia;
    private int mes;
    private int año;

    /**
     * Constructor de objetos de la clase fecha a aprtir de parametros enteros.
     * 
     * @param dia Para pasar el dia.
     * @param mes Para pasar el mes.
     * @param año Para pasar el año.
     */
    public Fecha(int dia,int mes,int año)
    {
        // Inicializar atributos
        this.dia = dia;
        this.mes = mes;
        this.año = año;
    }
    
    /**
     * Costructor de objetos para la clase fecha a partir de un String.
     * 
     * @param fechaS Para pasar el String que contiene la fecha
     */
    public Fecha(String fechaS)
    {
        // Array para almacenar las partes de la fecha divididas des String parámetro.
        String[] dividirFecha = fechaS.split("/");
        // Pasar los valores del array a los atributos.
        this.dia = Integer.valueOf(dividirFecha[0]);
        this.mes = Integer.valueOf(dividirFecha[1]);
        this.año = Integer.valueOf(dividirFecha[2]);
        
    }
    
    /**
     * Método que devuelve el dia de la fehca.
     * 
     * @return Devuelve el día de la fecha.
     */
    public int getDia()
    {
        return dia;
    }
    
    /**
     * Método que devuelve el mes de la fehca.
     * 
     * @return Devuelve el mes de la fecha.
     */
    public int getMes()
    {
        return mes;
    }
    
    /**
     * Método que devuelve el año de la fehca.
     * 
     * @return Devuelve el año de la fecha.
     */
    public int getAño()
    {
        return año;
    }
    
    /**
     * Redefinición del método hashCode(), que devuelve el código hash del atributo.
     * 
     * @return Devuelve el código hash del atributo número.
     */
    public int hashCode()
    {
        int hash = 9;
        hash = 49 * hash + Objects.hashCode(this.dia);
        return hash;
    }
    
    /**
     * Redefinición del método equals() para comparar si dos contactos son iguales.
     * 
     * @param obj objeto a comparar
     * @return Devuelve un booleano con el resultado de la comparación.
     */
    public boolean equals(Object obj)
    {
        if (obj instanceof Fecha) 
        {
            //Cast del objeto parámetro.
            Fecha tmpFecha = (Fecha) obj;
            //Son iguales si tienen el mismo nombre y telefono y ademas el mismo tipo de contacto
            if ((this.dia == (tmpFecha.dia)) && this.mes == (tmpFecha.mes))
            { 
                return true;
            } 
            else 
            { 
                return false; 
            }
        } 
        else
        { 
            return false;
        }
    } 
    
    /**
     * Método que devuelve la fecha.
     * 
     * @return Devuelve la fecha.
     */
    public String toString()
    {
        return "" + dia + "/" + mes + "/" + año;
    }
}
