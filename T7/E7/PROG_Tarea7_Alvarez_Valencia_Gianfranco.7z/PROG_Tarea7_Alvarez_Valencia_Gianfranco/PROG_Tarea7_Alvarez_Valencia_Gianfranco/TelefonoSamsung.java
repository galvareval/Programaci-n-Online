
/**
 * Clase que representa la marcas de móviles samsung
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_15_03_2022)
 */
public class TelefonoSamsung extends Telefono
{
    /**
     * Constructor for objects of class TelefonoSamsung
     */
    public TelefonoSamsung(String numero)
    {   
        // Inicializar superclase.
        super(numero);
    }

    /**
     * Devuelve la representación texto que indica la marca de móvil y el número de teléfono
     *
     * @return Devuelve la marca de móvil y el número de teléfono.
     */
    public String toString()
    {
        // Obtener el número mediante método de la super clase.
        return "Samsung (" + super.getNumero() + ")";
    }
}
