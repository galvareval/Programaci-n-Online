
/**
 * Clase que represnta una interfaz
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_15_03_2022)
 */
public interface Conferencia
{
    public String diaConferencia();
}
