import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
/**
 * Esta clase modela las caracteristicas de una persona genérica en el instituto.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_15_03_2022)
 */
public abstract class Persona implements Comparable<Persona>
{
    // Atributos
    private String nombre;
    private ArrayList<Telefono> listaTelefonos;

    /**
     * Constructor ed objetos para la clase persona
     * 
     * @param nombre Para pasar el nombre de la persona.
     */
    public Persona(String nombre)
    {
        // Inicializar atributos
        this.nombre = nombre;
        listaTelefonos = new ArrayList<Telefono>();
        
    }
    
    /**
     * Método para obtener el nombre de la persona.
     * 
     * @return Devuelve el nombre de la persona.
     */
    public String getNombre()
    {
        return nombre;
    }
    
    /**
     * Método que devuelve la lista de teléfonos de la persona.
     * 
     * @return Devuelve un string con la lista de teléfonos.
     */
    public String getListaTelefonos()
    {
        // Declarar resultado;
        String resultado = "";
        // Declarar iterador
        for (Telefono tel : listaTelefonos)
        {
            // Almacenar en resultado la representación String de los telefonos.
            resultado += tel + " ";//Usara redefinido?¿
        }
        return resultado;
    }
    /**
     * Método para añadir un teléfono a la lista de teléfonos de la persona.
     * 
     * @param  telefono Para pasar el teléfono a añadir.
     * @return Devuelve bolleano con el resultado de añadir el teléfono
     */
    public boolean addTelefono(Telefono telefono)
    {
        //listaTelefonos.add(telefono);//
        // Declarar resultado;
        boolean resultado = false;
        // añadir telefono
        listaTelefonos.add(telefono);
        //System.out.println("Añadopo tel");
        // Declarar iterador
        Iterator<Telefono> it;
        it = listaTelefonos.iterator();
        // Iterar la lista para comprobar si ya existe el número.
        while(it.hasNext())
        {
            Telefono tel = it.next();
            //System.out.println("entro primer if");
            if (tel.equals(telefono) == true)
            {
                //System.out.println("entro false");
                resultado = false;
            }
            else
            {
                //System.out.println("entro true");
                resultado =true;
            }
        }
        return resultado;
    }
    
    /**
     * Método que que devuelve el número de teléfonos de una persona.
     * 
     * @return Devuelve el número de telefonos de una persona.
     */
    public int cuantosTelefonos()
    {
        return listaTelefonos.size();
    }
    
    /**
     * Método que indica si una persona utiliza el ordenador
     * 
     * @return Devuelve un string con el resultado de como utiliza el ordenador.
     */
    public abstract String utilizarOrdenador();//En subclase
    
    /**
     * Redefinición del método hashCode(), que devuelve el código hash del atributo.
     * 
     * @return Devuelve el código hash del atributo nombre.
     */
    public int hashCode()
    {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.nombre);
        return hash;
    }
    
    /**
     * Redefinición del método equals() para comparar a dos personas
     * 
     * @param obj objeto a comparar
     * @return Devuelve un booleano con el resultado de la comparación.
     */
    public boolean equals(Object obj)
    {
        if (obj instanceof Persona) 
        {
            //Cast a objeto pasado parámetro
            Persona tmpPersona = (Persona) obj;
            //Son iguales si tienen el mismo nombew y pertenecen a la misma clase.
            if (this.nombre.equals(tmpPersona.nombre) &&  (this.getClass() == tmpPersona.getClass()))
            { 
                return true;
            } 
            else 
            { 
                return false; 
            }
        } 
        else
        { 
            return false;
        }
    }
    
    /**
     * Método para comparar personas por su nombew.
     * 
     * @param perAcomparar Para pasar la persona a comparar.
     * @return Devuelve un entero con el resutlado de la comparación.
     */
    public int compareTo(Persona perAcomparar)
    {
        if(this.nombre.length()==perAcomparar.nombre.length())
            return 0;
        else if (this.nombre.length()<perAcomparar.nombre.length())
            return -1;
        else
            return 1;
    }
    
    /**
     * Método que devuelve una representación textual incluyendo la clase a la que pertenece
     * la persona, el nombre de la persona, su lista de teléfonos 
     * y cómo utiliza el ordenador esa persona
     * 
     * @return Devuelve un string con la información de la persona.
     */
    public abstract String toString();//Redefinir en subclase
}
