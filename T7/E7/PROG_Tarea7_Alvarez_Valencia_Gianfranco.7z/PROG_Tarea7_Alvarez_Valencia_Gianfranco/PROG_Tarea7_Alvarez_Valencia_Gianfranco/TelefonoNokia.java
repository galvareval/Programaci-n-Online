
/**
 * Clase que representa la marcas de móviles samsung
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_15_03_2022)
 */
public class TelefonoNokia extends Telefono
{
    /**
     * Constructor for objects of class TelefonoNokia
     */
    public TelefonoNokia(String numero)
    {
        // Inicializar superclase.
        super(numero);
    }

    /**
     * Devuelve la representación texto que indica la marca de móvil y el número de teléfono
     *
     * @return Devuelve la marca de móvil y el número de teléfono.
     */
    public String toString()
    {
        // Obtener el número mediante método de la super clase.
        return "Nokia (" + super.getNumero() + ") ";
    }
}