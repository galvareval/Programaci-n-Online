
/**
 * Esta clase modela las caracteristicas de un Estudiante en el instituto.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_15_03_2022)
 */
public class Estudiante extends Persona
{
    /**
     * Constructor for objects of class Estudiante.
     * 
     * @param nombre Para pasar el nombre del estudiante.
     */
    public Estudiante(String nombre)
    {
        // Inicializar superclase 
        super(nombre);
    }

    /**
     * Método que indica si una persoa utiliza ordenador.
     * 
     * @return Devuelve un string con el resultado de como utiliza el ordenador.
     */
    public String utilizarOrdenador()
    {
        // Obtener el nombre mediante método de la super clase --usar getClass()?¿
        return "\nEl estudiante " + super.getNombre() + " utiliza el ordenador para hacer prácticas de programacion";

    }
    
    /**
     * Método que devuelve una representación textual incluyendo la clase a la que pertenece
     * la persona, el nombre de la persona, su lista de teléfonos 
     * y cómo utiliza el ordenador esa persona
     * 
     * @return Devuelve un string con la información de la persona.
     */
    public String toString()
    {
        String resultado = "";
        resultado += "\nClase Estudiante - " + super.getNombre() + "\n" + super.getListaTelefonos() + utilizarOrdenador() + "\n\n-----------------------------------------------------------------------------------";
        return resultado;
    }
}
