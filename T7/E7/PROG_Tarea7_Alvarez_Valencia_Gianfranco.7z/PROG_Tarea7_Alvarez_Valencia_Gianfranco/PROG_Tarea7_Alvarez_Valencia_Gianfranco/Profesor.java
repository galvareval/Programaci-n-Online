//import java.util.Objects;
/**
 * Esta clase modela las caracteristicas de un profesor en el instituto.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_15_03_2022)
 */
public class Profesor extends Persona implements Conferencia
{
    // instance variables - replace the example below with your own
    private Dia dia;
    /**
     * Constructor de la clase profesor.
     * 
     * @param nombre para pasar el nombre del profesor.
     * @param dia para pasar el dia de la semana.
     */
    public Profesor(String nombre,Dia dia)
    {
        // Inicializar superclase y atributo de subclase
        super(nombre);
        this.dia = dia;
        
    }

    /**
     * Método que indica si una persoa utiliza ordenador.
     * 
     * @return Devuelve un string con el resultado de como utiliza el ordenador.
     */
    public String utilizarOrdenador()
    {
        // Obtener el nombre mediante método de la super clase
        return "\nEl profesor " + super.getNombre() + " utiliza el ordenador para poner notas";

    }
    
    /**
     * Método que devuelve el dia que da conferencias un profesor.
     * 
     * @return Devuelve el día que da conferencias el profesor.
     */
    public String diaConferencia()
    {
        return dia.name();
    }
  
   /**
     * Método que devuelve una representación textual incluyendo la clase a la que pertenece
     * la persona, el nombre de la persona, su lista de teléfonos 
     * y cómo utiliza el ordenador esa persona
     * 
     * @return Devuelve un string con la información de la persona.
     */
    public String toString()
    {
        String resultado = "";
        resultado += "\nClase Profesor - " + super.getNombre() + "\n" + super.getListaTelefonos() + utilizarOrdenador() + " y da conferencias los " + diaConferencia() + "\n\n-----------------------------------------------------------------------------------";
        return resultado;
    }
}
