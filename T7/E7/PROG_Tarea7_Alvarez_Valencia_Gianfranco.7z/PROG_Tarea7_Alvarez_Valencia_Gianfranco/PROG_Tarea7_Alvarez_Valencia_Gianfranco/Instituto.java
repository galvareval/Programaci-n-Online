import java.util.ArrayList;
import java.util.Iterator;
//import java.util.Objects;
import java.util.*;
/**
 * Esta clase modela las caracteristicas de una persona genérica en el instituto.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_15_03_2022)
 */
public class Instituto 
{
    // Atributos
    private String nombre;
    private ArrayList<Persona> listaPersonas;
    /**
     * Constructor de la clase Instituto
     * 
     * @param nombre Para pasar el nombre del instituto.
     */
    public Instituto(String nombre)
    {
        // Inicializar atributos
        this.nombre = nombre;
        listaPersonas = new ArrayList<Persona>();
    }

    /**
     * Método para añadir una nueva persona a la lista mediante parámetro.
     * 
     * @param persona Parámetro para pasar la persona a añadir.
     */
    public void altaPersona(Persona persona)
    {
         // Declarar iterador
        Iterator<Persona> it;
        it = listaPersonas.iterator();
        // Para saber si esta en la lista.
        boolean estaEnLaLista = false; 
        // Comprobar persona corrrecta.
        if (persona != null)
        {
            // La lista no esta vacia
            if (listaPersonas.size() != 0)
            {
                // Recorrer la lista mediante el iterador,
                while(it.hasNext())
                {
                    Persona per = it.next();
                    // si esta en la lista el booleano estaEnLaLista a true
                    if(per.equals(persona) == true)
                    {
                        estaEnLaLista = true;
                    }
                }
                // Añadir si no esta en la lista.
                if(estaEnLaLista == false)   
                    listaPersonas.add(persona);
            }
            // La lista esta vacia, añadir
            else
                listaPersonas.add(persona);
        }
        else
            System.out.println("Parámetro incorrecto, persona no añadida.");
    }
    
    /**
     * Método que sirve para mostrar el número de estudiantes que hay.
     * 
     * @return Devuelve el Nº de estudiantes del instituto.
     */
    public int cuantosEstudiantes()
    {
        // Declarar iterador
        Iterator<Persona> it;
        it = listaPersonas.iterator();
        // Contador de estudiantes
        int contadorEstudiantes = 0;
        // Iterar la lista, si la clase de la persona es Estudiante; aumentar contador.
        while(it.hasNext())
            {
                Persona per = it.next();
                if(per.getClass().getSimpleName() == "Estudiante")
                {
                    contadorEstudiantes++;
                }
            }
        return contadorEstudiantes;
    }
    
    /**
     * Método que sirve para borrar los estudiantes que no tienen móvil.
     * 
     */
    public void borrarEstudiantes()
    {
        // Declarar iterador
        Iterator<Persona> it;
        it = listaPersonas.iterator();
        // Iterar la lista, si la persona no tiene telefonos y es estudiante->borrar persona
        while(it.hasNext())
            {
                Persona per = it.next();
                //
                if(per.cuantosTelefonos() == 0 && per.getClass().getSimpleName() == "Estudiante")
                {
                    it.remove();
                }
            }
    }
    
    /**
     * Método que sirve para mostrar los datos de todas las personas que hay en el instituto.
     */
    public void mostrar()
    {
        // String resultado
        String resultado = "";
        // Declarar iterador
        Iterator<Persona> it;
        it = listaPersonas.iterator();
        // Iterar la lista para sacar el string de la información de cada persona.
        while(it.hasNext())
            {
                Persona per = it.next();
                // Almacenar informacion de cada persona en el resultado
                resultado += per.toString();
            }
        // Imprimir resultado
        System.out.println(resultado);
    }
    
    /**
     * Método para devolver una lista con los profesores que dan conferencias un determinado día de la semana.
     * Ordenada por nombre.
     * 
     * @param queDia Para pasar el día a evaluar.
     * @return Devuelve una lista ordenada por nombre con los profesores que dan conferencia ese dia de la semana.
     */
    public ArrayList<Persona> quienDaConferenciasEn(Dia dia)
    {
        // Nueva lista para almacenar los profesores
        ArrayList<Persona> listaConferenciasEnDia = new ArrayList<Persona>();
        // Declarar iterador
        Iterator<Persona> it;
        it = listaPersonas.iterator();
        // Recorrer la lista mediante el iterador, 
        while(it.hasNext())
            {
                Persona per = it.next();
                // Comprobar que sea persona(profesor)
                if (per instanceof Profesor)
                {
                    // Si lo es hacer cast explícito para poder acceder a los métodos de profesor.
                    Profesor prof = (Profesor) per;
                    // Encontrar los profesrores con el dia de conferencia igual que el parámetro.
                    if (prof.diaConferencia().equals(dia.name()))
                    // Añadir a la lista de resultado
                        listaConferenciasEnDia.add(prof);
                }
            }
        // Ordenar
        Collections.sort(listaConferenciasEnDia);
        return listaConferenciasEnDia;
    }
    
    /**
     * Método que devuelve el nombre del instituto.
     * 
     * @return Devuelve el nombre del instituto.
     */
    public String getNombre()
    {
        return nombre;
    }
    
    /**
     * Método para limpiar la consola
     */
    public void clear()
    {
    System.out.print('\u000C');    
    }
    
}
