
/**
 * Tipo enumerado para representar edias de la semana.
 * 
 * @author (Gianfranco Álvarez) 
 * @version (01_15_03_2022)
 */
public enum Dia
{
    Lunes,Martes,Miercoles,Jueves,Viernes,Sabado,Domingo;
}
