import java.util.Objects;
/**
 * Esta clase modela las caracteristicas de un mobil
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_15_03_2022)
 */
public abstract class Telefono
{
    // Atributos
    private String numero;
    
    /**
     * Método contructor de la clase Telefono
     * Inicializa el número de teléfono
     * 
     */
    public Telefono(String numTelefono)
    {
        // Inicializar atributos
        this.numero = numTelefono;
    }
    
    /**
     * Método que devuelve el número de teléfono.
     * 
     * @return Devuelve el número de teléfono.
     */
    public String getNumero()
    {
        return numero;
    }
    
    /**
     * Método que devuelve una cadena indicado qúe número de teléfono llama a qué otro número.
     * 
     * @param telefono Parámetro para pasar el teléfono.
     * @return Devuelve un string con las caracterísiticas de la llamada.
     */
    public String llamar(Telefono telefono)
    {
        return "El número de teléfono" + numero + "llama a: " + telefono.getNumero();
    }
    
    /**
     * Redefinición del método hashCode(), que devuelve el código hash del atributo.
     * 
     * @return Devuelve el código hash del atributo número.
     */
    public int hashCode()
    {
        int hash = 9;
        hash = 49 * hash + Objects.hashCode(this.numero);
        return hash;
    }
    
    /**
     * Redefinición del método equals() para comparar si dos teléfonos son iguales.
     * 
     * @param obj objeto a comparar
     * @return Devuelve un booleano con el resultado de la comparación.
     */
    public boolean equals(Object obj)
    {
        if (obj instanceof Telefono) 
        {
            //Cast del objeto parámetro.
            Telefono tmpTelefono = (Telefono) obj;
            //Son igual si el método toString devuelve lo mismo y si son de la mis clase
            if (this.toString().equals(tmpTelefono.toString()) && (this.getClass() == tmpTelefono.getClass()))
            { 
                return true;
            } 
            else 
            { 
                return false; 
            }
        } 
        else
        { 
            return false;
        }
    }
        
    /**
     * Método para devolver el teléfono, redefinir en las subclases.
     * 
     * @return Devuelve la representación textual del teléfono.
     */
    public abstract String toString();
    
}
