
/**
 * Ejercicio 2 La clase Hashtable
 * 
 * @author (Gianfranco Álvarez valencia) 
 * @version (01_27_03_2022)
 */
public class Persona implements Comparable
{ 
    private String nombre; 
    private String apellido; 
    private long dni;

    public Persona (String nombre, String apellido, long dni)
    {
        this.nombre = nombre; 
        this.apellido = apellido; 
        this.dni = dni;
    }

    public String getNombre()
    { 
        return this.nombre;
    }

    public String getApellido()
    { 
        return this.apellido;
    }

    public long getDni()
    {
        return this.dni;
    }

    public boolean equals(Object obj)
    {
       if (obj instanceof Persona) 
        {
            //Cast a objeto pasado parámetro
            Persona tmpPersona = (Persona) obj;
            // Personas iguales si tienen mismo DNI.
            if (this.dni == (tmpPersona.dni))
            { 
                return true;
            } 
            else 
            { 
                return false; 
            }
        } 
        else
        { 
            return false;
        }
    }

    public int hashCode()
    {
        return 7*nombre.hashCode()+
        13*apellido.hashCode()+
        (new Long(this.dni)).hashCode();
    }
    
    public int compareTo(Object tmpPersona)
    { 
        Persona o = (Persona) tmpPersona;
        int result = nombre.compareTo(o.getNombre()); 
        if(result == 0)
        {
            result = apellido.compareTo(o.getApellido());
            if(result == 0)
            {
                return (new Long(dni)).compareTo((new Long(o.getDni())));
            }
            else
            {
                return result;
            }
        }
        else
        {
            return result;
        }
    }
}

