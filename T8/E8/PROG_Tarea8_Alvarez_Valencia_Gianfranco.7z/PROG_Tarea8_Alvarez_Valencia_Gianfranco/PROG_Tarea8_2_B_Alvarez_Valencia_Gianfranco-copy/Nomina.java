
/**
 * Ejercicio 2 La clase Hashtable
 * 
 * @author (Gianfranco Álvarez valencia) 
 * @version (01_27_03_2022)
 */
public class Nomina
{
    // instance variables - replace the example below with your own
    private double sueldoBase; 
    private double primas; 
    private double comisiones; 
    private double retenciones;

    public Nomina(double sueldoBase, double primas, double comisiones, double retenciones)
    { 
        this.sueldoBase = sueldoBase;
        this.primas = primas;
        this.comisiones = comisiones;
        this.retenciones = retenciones;
    }

    public double getSueldoBase()
    {
        return sueldoBase;
    }

    public double getPrimas()
    {
        return primas;
    }

    public double getComisiones()
    {
        return comisiones;
    }

    public double getRetenciones()
    {
        return retenciones;
    }
}

