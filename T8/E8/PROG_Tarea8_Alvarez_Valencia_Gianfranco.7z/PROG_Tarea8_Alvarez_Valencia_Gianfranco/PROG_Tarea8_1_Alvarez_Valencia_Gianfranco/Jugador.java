
/**
 * Esta clase modela las caracteristicas de una persona tipo Jugador en la liga.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_23_03_2022)
 */
public class Jugador extends Persona
{
    // Atributos subclase
    private int golesMarcados;

    /**
     * Constructor for objects of class Jugador
     * 
     * @param nombre Para pasar el nombre del jugador.
     * @param sueldo Para pasar el sueldo del jugador.
     */
    public Jugador(String nombre, int sueldo)
    {
        // Inicializar superclase.
        super(nombre,sueldo);
        // Inicializar atributos subclase.
        golesMarcados = 0;
    }

    /**
     * Método para obtener el Nº de goles marcados del jugador.
     * 
     * @return Devuelve el Nº de goles marcados.
     */
    public int getGolesMarcados()
    {
        return golesMarcados;
    }
    
    /**
     * Método para aumentar en uno la cantidad de goles marcados.
     * 
     */
    public void marcarGol()
    {
        golesMarcados += 1;
    }
    
    /**
     * Método para aumentar los goles marcados pasado por parámetro.
     * 
     * @param nGoles Para pasar el número de goles marcados.
     */
    public void marcarNgoles(int nGoles)
    {
        golesMarcados += nGoles;
    }
    
    /**
     * Método que devuelve una representación textual del jugador incluyendo su nombre, sueldo
     * y número de goles marcados.
     * 
     * @return Devuelve un string con la información del jugador.
     */
    public String toString()
    {
        String resultado = "";
        resultado += "\nJugador - " + super.getNombre() + "\nSueldo - " + super.getSueldo() + "\nGoles marcados - " + getGolesMarcados();
        return resultado;
    }
}
