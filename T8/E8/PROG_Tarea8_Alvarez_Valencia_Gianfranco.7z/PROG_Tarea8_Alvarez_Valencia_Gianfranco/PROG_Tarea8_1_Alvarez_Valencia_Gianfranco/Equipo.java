import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collections;
import java.util.Comparator;

/**
 * Esta clase modela las caracteristicas de un equipo en la liga.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_23_03_2022)
 */
public class Equipo
{
    // Atributos
    private String nombre;
    private ArrayList <Persona> jugadores;
    private Entrenador entrenador;
    
    /**
     * Constructor de objetos de la clase equipo.
     */
    public Equipo(String nombre)
    {
        // initialise instance variables
        this.nombre = nombre;
        jugadores = new ArrayList <Persona> ();
    }
    
    /**
     * Método para obtener el nombre del equipo.
     * 
     * @return Devuelve el nombre del equipo.
     */
    public String getNombre()
    {
        return nombre;
    }
    
    /**
     * Método para obtener el Entrenador del equipo.
     * 
     * @return Devuelve el Entrenador del equipo.
     */
    public Entrenador getEentrenador()
    {
        return entrenador;
    }
    
    /**
     * Método para definir el Entrenador del equipo.
     * 
     * @param Para pasar el Entrenador del equipo.
     */
    public void setEentrenador(Entrenador entrenador)
    {
        this.entrenador = entrenador;
    }
    
    /**
     * Método para añadir jugadores al equipo pasados mediante un array(si no existen ya en la lista)
     * 
     * @param jugadores Para pasar mediante un array los jugadores.
     */
    public void addJugadores(Jugador[] jugadores)
    {
        // Recorrer array y si no existe el jugador en el equipo, añadir a la lista.
        for (int i = 0;i < jugadores.length;i++)
        {
            if(!this.jugadores.contains(jugadores[i]))
                this.jugadores.add(jugadores[i]);
        }
    }
    
    /**
     * Método para añadir un jugador al equipo, si no está en el equipo.
     * 
     * @param jugador Para pasar el jugador a meter al equipo.
     */
    public void addJugador(Jugador jugador)
    {
        // Comprobar si no existe.
        if(!jugadores.contains(jugador))
                jugadores.add(jugador);
    }
    
    /**
     * Método que dado el nombre de un jugador, devuelve los goles que ha marcado en la liga.
     * 
     * @param nombre Para pasar el nombre del jugador a evaluar.
     * @return Devuelve el Nº de goles que ha marcado el jugador en la liga.
     */
    public int golesDe(String nombre)
    {
        int golesResultado = 0; //Inicializar  a 0, caso jugador no encotrado.
        // Var para almacenar el jgador buscado por el nombre.
        Persona jugadorBuscado = buscarJugador(nombre);
        // Si el jugador no es null, esta en el equipo-> obtener nªgoles.
        if( jugadorBuscado != null)
            {
                if (jugadorBuscado instanceof Jugador)//Cast
                {
                    // Si lo es hacer cast explícito para usar métodos
                    Jugador jugadorEncontrado = (Jugador) jugadorBuscado;
                    golesResultado = jugadorEncontrado.getGolesMarcados();
                }
                
            }
        return golesResultado;    
    }
    
    /**
     * Método que devuelve la relación de jugadores mejor pagados.
     * 
     * @return Devuelve una lista con la relación de jugadores mejores pagados.//Que hace este método?
     */
    public ArrayList<Persona> mejorPagado()
    {
         // Para devolver el resultado sin alterar ArrayList original.
        ArrayList<Persona> resultado = new ArrayList<Persona>(jugadores);
        // Almacenar en resultado los jugadores.quitar
        //resultado = jugadores;quitar
        // Ordenar por criterio de sueldo.
        Collections.sort(resultado, new ComparadorSueldo());
        return resultado;
    }
    
    /**
     * Método que dado un nombre de un jugador devuelve el jugador.
     * 
     * @param nombre Para pasar el nombre del jugador buscado.
     * @return Devuelve la persona que corresponde al nombre pasado.
     */
    private Persona buscarJugador(String nombre)
    {
        // Var aux para saber si el jugador esta en la lista.
        Persona perResultado = null;// Iinicializar a nulo
        // Declarar iterador
        Iterator<Persona> it;
        it = jugadores.iterator();
         // Recorrer la lista mediante el iterador, si está en el quipo guardar en perResultado.
        while(it.hasNext())
        {
            Persona per = it.next();
            if(per.getNombre().equals(nombre) == true)
                perResultado = per;
        }
        return perResultado;
    }
    
    /**
     * Método que muestra un listado en orden alfabético de los jugadores del equipo.
     * 
     */
    public void listarOrdenAlfabetico()
    {
         // Para devolver el resultado son modfiicar la lista original.
        ArrayList<Persona> resultado = new ArrayList<Persona>(jugadores);
        // Almacenar en resultado los jugadores.quitar
        //resultado = jugadores;quitar
        // Usar clase anónima para ordenar alfabéticamente con Comparator.
        Collections.sort(resultado, new Comparator<Persona>(){
            public int compare(Persona p1, Persona p2)
            {
                return p1.getNombre().compareTo(p2.getNombre());
            }
        
        });
        escribir(resultado);
        }
    
    /**
     * Método que muestra un listado ordenado de menor a mayor sueldo de los jugadores del equipo.
     */
    public void listarPorSueldo()
    {
         escribir(mejorPagado());   
    }
    
    /**
     * Método para escribir por pantalla un equipo.
     * 
     * @param jugadores Para pasar la lista de jugadores  a escribir por pantalla.
     * 
     */
    private void escribir(ArrayList<Persona> jugadores)
    {
        // Declarar iterador
        Iterator<Persona> it;
        it = jugadores.iterator();
         // Recorrer la lista mediante el iterador e imprimir por pantalla los jugadores de la lista.
        while(it.hasNext())
        {
            Persona per = it.next();
            System.out.println(per.toString());
        }
        
    }
    
    /**
     * Método que devuelve el jugador pichichi del equipo.
     * 
     * @return Devuelve la Persona pichichi.
     */
    public Persona pichichi()
    {
        // Var aux para saber el pichichi
        // Iinicializar al primer jugador.
        Persona pichichi = jugadores.get(0);
        Jugador pich = (Jugador) pichichi;// Cast
        // Declarar iterador
        Iterator<Persona> it;
        it = jugadores.iterator();
         // Recorrer la lista mediante el iterador e imprimir por pantalla los jugadores de la lista.
        while(it.hasNext())
        {
            Persona per = it.next();
            if( per != null)
                if(pich == null)
                    pichichi = per;
                if (per instanceof Jugador)//Cast
                    {
                        // Si lo es hacer cast explícito para usar métodos
                        Jugador jug = (Jugador) per;
                        if (jug.getGolesMarcados() > pich.getGolesMarcados())
                            pich = jug;
                    }
        }
        return pich;
        
    }
    
    /**
     * Método que devuelve un string con los jugadores del equipo.
     * 
     * @retrun Devuelve un string con los jugadores del equipo.
     */
    public String toString()
    {
        // Para almacenar el resultado.
        String resultado = "";
        resultado += "*****Equipo: " + getNombre() + "*****";
        // Declarar iterador
        Iterator<Persona> it;
        it = jugadores.iterator();
         // Recorrer la lista mediante el iterador, alamcenar la informacón de cada jugador del equipo en el resultado
        while(it.hasNext())
        {
            Persona per = it.next();
            resultado += per.toString() + "\n";
        }
        return resultado;
    }
}
