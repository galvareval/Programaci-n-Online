
/**
 * Esta clase modela las caracteristicas de una persona tipo Entrenador de un equipo en la liga.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_23_03_2022)
 */
public class Entrenador extends Persona
{
    // Atributos 
    private Equipo equipo;

    /**
     * Constructor de objetos de la clase Entrenador
     */
    public Entrenador(String nombre, int sueldo, Equipo equipo)
    {
        // Inicializar superclase.
        super(nombre,sueldo);
        // Inicializar atributos subclase.
        this.equipo = equipo; 
    }

    /**
     * Método para definir el Equipo del Entrenador
     * 
     * @para equipo Para pasar el Equipo del Entrenado.
     */
    public void setEquipo(Equipo equipo)
    {
        this.equipo = equipo;
    }
    
    /**
     * Método para obtener el Equipo del Entrenador.
     * 
     * @return Devuelve el Equipo del Entrenador.
     */
    public Equipo getEquipo()
    {
        return equipo;
    }
    
    public String toString()
    {
        String resultado = "";
        resultado += "\nClase Entrenador - " + super.getNombre() + "\n" + super.getSueldo() + "\n" + equipo.getNombre();
        return resultado;
    }
}
