import java.util.Comparator;

/**
 * Esta clase se usa para establecer la relación de sueldos.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_23_03_2022)
 */
public class ComparadorSueldo implements Comparator<Persona> 
{
    public int compare(Persona o1, Persona o2) 
    {
        return o1.getSueldo() - o2.getSueldo(); // Devuelve un entero positivo si el sueldo de o1 es mayor que el de o2
    }
}

