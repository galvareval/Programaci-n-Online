import java.util.Objects;
/**
 * Esta clase modela las caracteristicas de una persona genérica en la liga.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_23_03_2022)
 */
public abstract class Persona implements Comparable<Persona>
{
    // Atributos
    private String nombre;
    private int sueldo;

    /**
     * Constructor for objects of class Persona
     */
    public Persona(String nombre, int sueldo)
    {
        // Inicializar atributos.
        this.nombre = nombre;
        this.sueldo = sueldo;
    }
    
    /**
     * Método para obtener el nombre de la persona.
     * 
     * @return Devuelve el nombre de la persona.
     */
    public String getNombre()
    {
        return nombre;
    }
    
    /**
     * Método para definir el nombre de la persona
     * 
     * @para nombre Para pasar el nombre de la persona.
     */
    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }
    
    /**
     * Método para obtener el sueldo de la persona.
     * 
     * @return Devuelve el sueldo de la persona.
     */
    public int getSueldo()
    {
        return sueldo;
    }
    
    /**
     * Método para definir el sueldo de la persona
     * 
     * @para sueldo Para pasar el sueldo de la persona.
     */
    public void setSueldo(int sueldo)
    {
        this.sueldo = sueldo;
    }
    
    /**
     * Redefinición del método hashCode(), que devuelve el código hash del atributo.
     * 
     * @return Devuelve el código hash del atributo nombre.
     */
    public int hashCode()
    {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.nombre);
        return hash;
    }
    
    /**
     * Redefinición del método equals() para comparar a dos personas
     * 
     * @param obj objeto a comparar
     * @return Devuelve un booleano con el resultado de la comparación.
     */
    public boolean equals(Object obj)
    {
        if (obj instanceof Persona) 
        {
            //Cast a objeto pasado parámetro
            Persona tmpPersona = (Persona) obj;
            //Son iguales si tienen el mismo nombre, sueldo y pertenecen a la misma clase(mismo tipo).
            if (this.nombre.equals(tmpPersona.nombre) && this.sueldo == (tmpPersona.sueldo) &&  (this.getClass() == tmpPersona.getClass()))
            { 
                return true;
            } 
            else 
            { 
                return false; 
            }
        } 
        else
        { 
            return false;
        }
    }
    
    /**
     * Método para comparar personas por su sueldo.
     * 
     * @param perAcomparar Para pasar la persona a comparar.
     * @return Devuelve un entero con el resutlado de la comparación.
     */
    public int compareTo(Persona perAcomparar)
    {
        // para ordenar por sueldo ascendente**interfaz comparator?
       return this.sueldo - (perAcomparar.sueldo);
    }
    
    /**
     * Método que devuelve una representación textual incluyendo la clase a la que pertenece
     * la persona, el nombre de la persona, su lista de teléfonos 
     * 
     * @return Devuelve un string con la información de la persona.
     */
    public abstract String toString();//Redefinir en subclase
}
