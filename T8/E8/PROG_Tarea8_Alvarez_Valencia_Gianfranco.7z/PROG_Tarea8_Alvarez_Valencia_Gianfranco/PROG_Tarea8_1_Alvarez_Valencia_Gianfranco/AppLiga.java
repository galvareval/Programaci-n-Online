import java.util.Scanner;
/**
 * Calse para hacer Test here.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_23_03_2022)
 */
public class AppLiga
{
    private static final Scanner teclado = new Scanner(System.in);
    public static void main (String[] args)
    {
        // Para pasar año de teclado
        String año;
        System.out.println("Introduzca el año de la liga: ");
        año = teclado.nextLine();
        Liga liga1 = new Liga("año");
        // Cargar el fichero.
        liga1.cargarDeFichero();
        // Capturar la expeción que arroja el método salvarEnFichero().
        try
        {
            liga1.salvarEnFichero();
        }
        catch (java.io.IOException ioe)
        {
            ioe.printStackTrace();
        }
        //Prueba devolver el pichichi de la liga.
        System.out.println("Pichcihi de la liga: " + liga1.pichichi());
        // Prueba métodos de las clases.
        System.out.println("Prueba de los métodos de las clases: ");
        probarMetodos();
    }
    
    /**
     * Método para probar los métodos de las clases Equipo, Persona(Jugador, Entrenador).
     */
    public static void probarMetodos()
    {
        // Equipo gian para; añadir jugador uno a uno
        Equipo gian = new Equipo ("eq_gian");
        Jugador j1 = new Jugador("ana",200);
        Jugador j2 = new Jugador("bartomeu",100);
        Jugador j3 = new Jugador("carlos",300);
        // Crear un entrandor.
        Persona mister = new Entrenador("mister",800,gian);
        gian.addJugador(j1);
        gian.addJugador(j2);
        gian.addJugador(j3);
        gian.addJugador(j3);
        // Mostrar equipo.
        System.out.println(gian.toString());
        // Ordenar por sueldo.
        gian.listarPorSueldo();
        // Ordenar por oden alfabético.
        gian.listarOrdenAlfabetico();
        // Mostrar el pichichi(todos 0 goles).
        System.out.println("*****El pichichi es: " + gian.pichichi());
        // Hacer que uno marque gol.
        j2.marcarGol();
        // Vers nuevo pichichi.
        System.out.println(j2.getNombre() + " marca gol,el pichichi es: " + gian.pichichi());
        // Hacer que otro jugador marque 3 goles
        j3.marcarNgoles(3);
        // Ver nuevo puchichi
        System.out.println(j3.getNombre() + " marca 3 goles el pichichi es: " + gian.pichichi());
        // Ver goles dado un nombre
        System.out.println("los goles de ana son: " + gian.golesDe("ana"));
        System.out.println("los goles de bartomeu son: " + gian.golesDe("bartomeu"));
        System.out.println("los goles de carlos son: " + gian.golesDe("carlos"));
        // Prueba añadir con array
        //Equipo array; añadir jugadores mediante array.
        Equipo array = new Equipo ("eq_array");
        // Crear array para almacenar los jugadores.
        Jugador[] jugadores = new Jugador[5]; 
        // Llenar el array con jugadores.
        for (int i = 0;i < jugadores.length;i++)
        {
            jugadores[i] = new Jugador("j" + i,i);
        }
        // add
        System.out.println("Meter los jugadores del array");
        array.addJugadores(jugadores);
        // Imprimir
        System.out.println(array.toString());
    }
}
