import java.util.TreeMap;
import java.util.Comparator;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.Map;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.BufferedWriter;
import java.util.Iterator;

/**
 * Esta clase representa a la liga del año en curso.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_23_03_2022)
 */
public class Liga
{
    // Atributos.
    private String año;
    TreeMap<String, Equipo> equipos;
    /**
     * Constructor for objects of class Liga
     */
    public Liga(String año)
    {
        // Inicializar año
        this.año = año;
        // Nuevo objeto TreeMap
        equipos = new TreeMap<String, Equipo>
        (
            new Comparator<String>() 
                {
                    public int compare(String obj1, String obj2) 
                {
                        // Ordenar en orden alfabetico por Key
                        return obj1.compareTo(obj2);
                    }
                }
        );
    }

    /**
     * Método para leer los datos de los equipos desde el fichero"equipos.txt"
     *  
     */
    public void cargarDeFichero()
    {
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        try
        {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            archivo = new File ("./equipos.txt");//equipos.txt -> probar x1 equipo; equipos_varios.txt probar xvarios equipos.
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            // Lectura del fichero
            String linea;// Primera linea
            while((linea=br.readLine())!=null)// Para leer todo el fichero hasta que linea sea vacía
            {
                // Lectura de la linea, info del equipo(nombre:nºJugadores:Nombre_entrenador:sueldo_entrenador
                String lineaDatosEquipo = linea; 
                // Almacenar datosEquipo.
                String [] arrayDatosEquipo = new String[obtenerDatosDeLinea(lineaDatosEquipo).length];
                arrayDatosEquipo = obtenerDatosDeLinea(lineaDatosEquipo);
                // Crear Equipo(obj) para meter a la liga.
                Equipo equipoAux = new Equipo(arrayDatosEquipo[0]);
                // Crear Entrenador(obj).
                Entrenador entrenadorAux = new Entrenador(arrayDatosEquipo[2], Integer.valueOf(arrayDatosEquipo[3]), equipoAux);
                // Set entrenador al equipo.
                equipoAux.setEentrenador(entrenadorAux);
                // Leer jugadores
                // String para almaceanr los datos de los jugadores, estań a partir de la linea de la info del equipo hasta el nº jugadores.
                String lineaDatosJugador;
                // Recorrer tantas lineas como jugadores halla.
                // De cada linea del fichero crear un objeto jugador y almacenarlo en un array de Jugadores.
                // Array de jugadores con dimensión el número de jugadores.
                Jugador [] jugadores = new Jugador[Integer.valueOf(arrayDatosEquipo[1])];
                for (int i = 0;i < Integer.valueOf(arrayDatosEquipo[1]);i++)
                    {
                        lineaDatosJugador = br.readLine(); 
                        jugadores[i] = crearJugador(obtenerDatosDeLinea(lineaDatosJugador));// Crear jugador a partir de los datos de la linea.
                    }
                // Añadir jugadores al equipo.
                equipoAux.addJugadores(jugadores);
                // Añadir equipo al Map.
                equipos.put(arrayDatosEquipo[0],equipoAux);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
        // En el finally cerramos el fichero, para asegurarnos
        // que se cierra tanto si todo va bien como si salta 
        // una excepcion.
            try
            {                    
                if( null != fr )
                {   
                    fr.close();     
                }                  
            }
            catch (Exception e2)
            { 
                e2.printStackTrace();
            }
        }
        /*Prueba a imprimir el TreeMap
        // Para almacenar el resultado.
        String resultado = "Prueba impirmir equipos";
        // Iterar el map .
        for(Map.Entry<String,Equipo> lista: equipos.entrySet())
        {
            resultado += "\n" + lista.getKey() + " - " + lista.getValue();
        }
        System.out.println(resultado);*/
    }
    
    /**
     * Método que guarda en un fichero salida.txt los equipos disponibles junto con el nombre de su pichichi.
     * 
     */
    public void salvarEnFichero() throws IOException
    {
        PrintWriter salida = null;
        salida = new PrintWriter(new BufferedWriter(new FileWriter("salida.txt")));
        salida.println(equipoYpichichi());
        salida.close();
    }
    
    /**
     * Método para obtener un string con el TreeMap de equipos disponibles.
     * 
     * @return Devuelve un string con los equipos disponibles y su pichichi.
     */
    private String equipoYpichichi ()
    {
        // Para almacenar el resultado.
        String resultado = "";
        // Iterar el map .
        for(Map.Entry<String, Equipo> lista: equipos.entrySet())
        {
            resultado += "Equipo: " + lista.getKey() + " Pichichi: " + (lista.getValue().pichichi()).getNombre() + "\n";
        }
        return resultado;
    }
    
    /**
     * Método que devuelve el nombre del equipo que tiene al pichichi de la liga.
     * 
     * @return Devuelve un String con el nombre del pichichi de la liga.
     */
    public String pichichi()
    {
        Persona pichichiDeLiga = null;
         // Para almacenar los pichichis de cada equipo.
        ArrayList<Persona> pichichisEquipos = new ArrayList<Persona>();
        // Iterar el map .
        for(Map.Entry<String, Equipo> lista: equipos.entrySet())
        {
             pichichisEquipos.add(lista.getValue().pichichi());
        }
        // Asignar el pichichiDeLiga al pichichi del primer equipo.
        pichichiDeLiga = pichichisEquipos.get(0);
        // iterar la lista en busca del pichichi.
        Jugador pich = (Jugador) pichichiDeLiga;// Cast
        // Declarar iterador
        Iterator<Persona> it;
        it = pichichisEquipos.iterator();
         // Recorrer la lista mediante el iterador en busca del pichichi.
        while(it.hasNext())
        {
            Persona per = it.next();
            if( per != null)
                if (per instanceof Jugador)//Cast
                    {
                        // Si lo es hacer cast explícito para usar métodos
                        Jugador jug = (Jugador) per;
                        if (jug.getGolesMarcados() > pich.getGolesMarcados())
                            pich = jug;
                    }
        }
        return pich.getNombre();
    }
    /**
     * Método para obtener los datos de un string separados por un delimitador ":"
     * 
     * @param datos Para pasar el String del que se obtendrán los datos.
     * @return Devuelve un array con los datos obtenidos.
     */
    private String[] obtenerDatosDeLinea(String datos)
    {
        // Token para almacenar los datos del string separados por ":".
        StringTokenizer tokens = new StringTokenizer(datos, ":");
         // Numero de tokens para dimension del Array que contendrá los datos.
        int nDatos = tokens.countTokens();
        // Para recorrer el array de datos de la persona.
        int i = 0;
        // Array String de datos del string parámetro con dimensión = Numero de tokens.
        String [] arrayDatos = new String[nDatos];
        // Pasar los tokens al Array.
        while(tokens.hasMoreTokens())
        {
            String cadena = tokens.nextToken();
            arrayDatos[i] = cadena;
            i++;
        }
        return arrayDatos;
    }
    
    /**
     * Método para crear un Jugador(obj) a partir de los datos de un string pasado.
     * 
     * @param datosJugador Para pasar los datos.
     * @return Devuelve el jugador a partir de los datos pasados.
     */
    private Jugador crearJugador(String [] datosJugador)
    {
        // Crear un nuevo jugador a partir de los datos.
        // Hacer coinicidir tipos de datos.
        Jugador jugadorAcrear = new Jugador(datosJugador[0], Integer.valueOf(datosJugador[1]));
        jugadorAcrear.marcarNgoles(Integer.valueOf(datosJugador[2]));
        return jugadorAcrear;
    }    
}