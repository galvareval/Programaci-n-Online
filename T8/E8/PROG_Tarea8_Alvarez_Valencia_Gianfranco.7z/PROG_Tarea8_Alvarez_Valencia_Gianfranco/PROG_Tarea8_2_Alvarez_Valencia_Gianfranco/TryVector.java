import java.util.*; 
import java.awt.Point;
/**
 * Ejercicio 1 tarea 8_2. Vector
 * 
 * @author (Gianfrnaco Álvarez Valencia) 
 * @version (01_27_03_2022)
 */
public class TryVector 
{
    public static void main (String [] args) 
    {
        Vector vecPuntos = new Vector();
        Point[] points = {new Point(3,2),new Point(8,6),new Point(3,4)}; 
        for(int i = 0; i < points.length; i++)
        {
            vecPuntos.add(points[i]);
            for(int j = i; j < vecPuntos.size(); j++)
            {
                Point po = (Point)vecPuntos.get(j);
                System.out.println("El punto "+ j +" tiene coordenadas:");
                System.out.println("X: " + po.getX());
                System.out.println("Y: " + po.getY());
            }
        }
    }
}