/**
 * Este proyecto crea una representación del triángulo(n) de Tartaglia a partir de un número de filas(n) pasado por teclado.
 * Esta clase contiene el método main de la apliación para iniciarla.
 * Pide al usuario el número de filas del triángulo a representar y lo imprime por pantalla.
 *
 * @author (Gianfranco Álvarez)
 * @version (01_25_11_2021)
 */

public class AppTartaglia
{
    /**
     * Método main, contiene las sentencias necesarias para iniciar la aplicación.
     */
    public static void main(String[] args)
    {
        //Obejto de la clase que controla el programa.
        InterfazTartaglia inicio;
        //Crear el objeto.
        inicio = new InterfazTartaglia();
        //Ejecutar la aplicación.
        inicio.ejecutar();
    }
}