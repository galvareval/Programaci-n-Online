/**
 * Este proyecto crea una representación del triángulo(n) de Tartaglia a partir de un número de filas(n) pasado por teclado.
 * Esta clase se utiliza para calcular combinaciones de dos números.
 *
 * @author (Gianfranco Álvarez)
 * @version (02_29_11_2021)
 */

public class NumeroCombinatorio
{
    private int n;
    private int m;
    
    /**
     * Constructor de objetos para la clase NumeroCombinatorio.
     * Inicializa m y n a 0.
     *
     */
    public NumeroCombinatorio()
    {
          n = 0;
          m = 0;
    }
    
    /**
     * Método que calcula el factorial de un número pasado como parámetro.
     * 
     * @param numero Parámetro que contiene el número del cual se calculará su factorial.
     * @return Devuelve el factorial del número.
     */
    
    private int factorial(int numero)
    {
        //Caso base.
        if (numero == 0)
            return 1;
        //Recusión.    
        else
            return numero * factorial(numero-1);
    }
    
    /**
     * Método para cargar valor de n mediante parámetro.
     * 
     * @param n Parámetro para pasar el valor de n.
     */
    public void setN(int n)
    {
        this.n = n; 
    }
    
    /**
     * Método para cargar valor de n mediante parámetro.
     * 
     * @param m Parámetro para pasar el valor de m.
     */
    public void setM(int m)
    {
        this.m = m; 
    }
    
    /**
     * Método que devuelve el valor de n.
     * 
     * @return Devuelve el valor de n.
     */
    public int getN()
    {
        return n;
    }
    
    /**
     * Método que devuelve el valor de m.
     * 
     * @return Devuelve el valor de m.
     */
    public int getM()
    {
        return m;
    }
    
    /**
     * Método que calcula y devuelve el valor del númreo combinatorio representado por n y m.
     * @return Devuelve El número combinatorio de m y n.
     */
    
    public int obtenerCombinatorio()
    {
        return factorial(n) / (factorial(m) * factorial(n-m));
    }
}