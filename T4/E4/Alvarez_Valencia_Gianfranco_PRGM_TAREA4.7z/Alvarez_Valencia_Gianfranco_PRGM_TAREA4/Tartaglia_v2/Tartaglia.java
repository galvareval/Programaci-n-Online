/**
 * Este proyecto crea una representación del triángulo(n) de Tartaglia a partir de un número de filas(n) pasado por teclado.
 * Esta clase se utiliza para generar el triángulo de Tartaglia de dimension n.
 *
 * @author (Gianfranco Álvarez)
 * @version (02_29_11_2021)
 */

public class Tartaglia
{
    private int filas;
    private NumeroCombinatorio nc;
    
    /**
     * Constructor de objetos sobrecargado de la clase Tartaglia con parámetro, crea un objeto de la clase NumeroCombinatorio.
     * 
     * @param filas Parámetro que pasa el número de filas.
     */
    public Tartaglia(int filas)
    {
        //Pasar a atributo filas el valor del paŕametro.
        this.filas= filas;
        //Nuevo objeto de la clase NumeroCombinatorio
        nc = new NumeroCombinatorio();
    }
    
    /**
     * Constructor de objetos sobrecargado de la clase Tartaglia.
     * Iniciliza las filas a 0 y crea un objeto de la clase NumeroCombinatorio.
     */
    public Tartaglia()
    {
        //Inicializar filas.
        filas = 0;
        //Nuevo objeto de la clase NumeroCombinatorio.
        nc = new NumeroCombinatorio();
    }
    
    /**
     * Método para imprimir blancos a partir de un parámetro.
     * 
     * @param cuantos Parámetro para pasar el número de blancos a imprimir.
     */
    private void escribirTerminoVacio(int cuantos)
    {
        for (int k = 1;k <= cuantos;k++)
        {
            System.out.print(" ");
        }
    }
    
    /**
     * Método que genera y dibuja el triángulo en pantalla.
     */
    public void dibujar()
    {
        for(int i = 0;i <= filas-1;i++)
        {
            //Imprime blancos para generar el triangulo entero.
            escribirTerminoVacio(filas-1-i);
            for(int j = 0;j <= i; j++)
            {
                //Casos en el triángulo en los que el resultado es 1.
                if (j == 0 || j == i)
                System.out.print(1 + " ");
                else
                {
                    //Pasar el valor del primer número.
                    nc.setN(i);
                    //Pasar el valor del segundo número.
                    nc.setM(j);
                    //Calcular número combinatorio e imprimirlo.
                    System.out.print(nc.obtenerCombinatorio() + " ");
                }
            }
        System.out.println();
        }
    }
    
    /**
     * Método para mostrar el número de filas.
     * 
     * @return Devuelve el número de filas.
     */
    public int getFilas()
    {
        return filas;
    }
    
    /**
     * Método para cargar el número de filas.
     * 
     * @param filas Parámetro para cargar el número de filas.
     */
    public void setFilas(int filas)
    {
        //Pasar a atributo filas el valor del paŕametro.
        this.filas = filas;
    }
}