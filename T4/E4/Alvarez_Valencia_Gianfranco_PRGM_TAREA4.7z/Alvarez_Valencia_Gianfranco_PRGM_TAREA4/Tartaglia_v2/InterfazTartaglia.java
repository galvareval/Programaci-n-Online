import java.util.Scanner;//import para usar entrada por teclado.
/**
 * Este proyecto crea una representación del triángulo(n) de Tartaglia a partir de un número de filas(n) pasado por teclado.
 * Esta clase controla la lógica de ejecución del programa.
 * Pide al usuario el número de filas del triángulo a representar y lo imprime por pantalla.
 *
 * @author (Gianfranco Álvarez)
 * @version (02_29_11_2021)
 */

public class InterfazTartaglia
{
    final char SI = 's';
    private Tartaglia triangulo;
    //objeto de la clase Scanner para obtener valores por teclado.
    private Scanner teclado;
    
    /**
     * Constructor de objetos de la clase InterfazTartaglia.
     * Inicializa los objetos a null.
     */
    public InterfazTartaglia()
    {
        //Inicializar.
        triangulo = null;
        teclado = null;
    }
    
    /**
     * Método que controla la lógica de ejecución.
     * Repite la ejecución del progrma hasta que el usuario quiera.
     */
    public void ejecutar()
    {
        //Bucle para repetir el programa hasta que usuario quiera-> <>'s'
        do
        {
            //Obtener número de filas y crear obj de class Tartaglia.
            triangulo = new Tartaglia(leerFilas());
            //Mostrar el dibujo del triangulo de dimension n.
            triangulo.dibujar();
        }
        while (continuar() == SI);
    }
    
    /**
     * Método para obtener por teclado el número de filas que tiene que tener el triágulo.
     * @return Devuelve el número de filas introducido por teclado.
     */
    private int leerFilas()
    {
        //Crea obj de la clase Scanner.
        Scanner teclado = new Scanner(System.in);
        //Obtener desde teclado.
        System.out.print("¿Número de filas?: ");
        return teclado.nextInt();
    }
    
    /**
     * Método para leer la respuesta del usuario de si desea continuar la ejecución(s).
     * Cualquier otra cosa detiene la ejecución.
     * @return Devuelve la respuesta del usuario.
     */
    private char continuar()
    {
        //Crea objeto de la clase Scanner.
        Scanner teclado = new Scanner(System.in); 
        //Obtener desde teclado.
        System.out.print("¿Deseas volver a ejecutar?: ");
        return teclado.next().charAt(0);
    }
    
    /**
     * Método para borrar la pantalla.
     */
    public void borrarPantalla()
    {
        System.out.print('\u000C');
    }
    
}