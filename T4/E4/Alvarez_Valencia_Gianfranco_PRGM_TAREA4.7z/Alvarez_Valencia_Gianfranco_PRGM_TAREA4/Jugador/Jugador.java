/**
 * Este proyecto modela un equipo de jugadores de futbol.
 * De cada jugador se registra el nombre, el sueldo y el número de goles marcados.
 *
 * @author (Gianfranco Álvarez)
 * @version (01_17_11_2021)
 */
public class Jugador
{
    //private static final String saltoLinea = System.getProperty("line.separator");
    //Almacena el nombre del jugador.
    private String nombre;
    //Almacena el sueldo del jugador.
    private double sueldo;
    //Almacena la cantidad de goles marcados.
    private int golesMarcados;
    
    /**
     * Constructor de objetos para la clase Jugador.
     * Se carga mediante parámetro el nombre y el sueldo del jugador.
     * Inicializa la cantidad de goles marcados a 0.
     * 
     * @param nombre Parámetro para cargar el nombre del jugador.
     * @param sueldo Parámetro para cargar el sueldo del jugador.
     */
    
    public Jugador(String nombre, double sueldo)
    {
        //Atributo nombre se carga con el valor del parámetro nombre.
        this.nombre = nombre;
        //Atributo sueldo se carga con el valor del parámetro sueldo.
        this.sueldo = sueldo;
        //Inicializa los goles marcados a 0.
        golesMarcados = 0;
    }
    
    /**
     * Método para obetener el nombre del jugador.
     * 
     * @return Devuelve el nombre del jugador.
     */
    
    public String getNombre()
    {
        return nombre;
    }
    
    /**
     * Método para obetener el sueldo del jugador.
     * 
     * @return Devuelve el sueldo del jugador.
     */
    
    public double getSueldo()
    {
        return sueldo;
    }
    
    /**
     * Método para aumentar en 1 la cantidad de goles de un jugador.
     * 
     */
    
    public void marcarGol()
    {
        //Sumar 1 al total de goles marcados.
        golesMarcados+=1;
    }
    
    /**
     * Método para obetener el número total de goles marcados del jugador.
     * 
     * @return Devuelve el número total de goles marcados del jugador.
     */
    
    public int getGoles()
    {
        return golesMarcados;
    }
    
    /**
     * Método que devuelve la representación textual del jugador.
     * 
     * @return  Muestra una representación textual del jugador.
     */
    
    public String toString()
    {
        //System.out.print("\n\tNombre: " + nombre + "\n\tSueldo: " + sueldo + "\n\tGoles marcados: " + golesMarcados + "\n");//Para ver por consola.
        return "\n\tNombre: " + nombre + "\n\tSueldo: " + sueldo + "\n\tGoles marcados: " + golesMarcados + "\n"; 
    }
}

