/**
 * Este proyecto modela un equipo de juagadores de futbol.
 * De cada jugador se registra el nombre, el sueldo y el número de goles marcados.
 * El equipo tiene un máximo de 3 jugadores.
 * Los jugadores se añaden al equipo asignando las en orden: 1>>2>>3.
 *
 * @author (Gianfranco Álvarez)
 * @version (01_17_11_2021)
 */
public class Equipo 
{
    //Guarda la referencia al orden en que se añade un jugador al equipo.
    private int contadorJugadores;
    //Nombre del equipo.
    private String nombre;
    //Los 3 jugadores que puede tener el equipo; de la clase jugador.
    private Jugador jugador1;
    private Jugador jugador2;
    private Jugador jugador3;
    
    /**
     * Constructor de obejetos d ela clase Equipo.
     * Se carga mediante parámetro el nombre del equipo.
     * Inicializa las referencias a los jugadores a null.
     * Inicializa el contador de jugadores a 0.
     * 
     * @param nombre Parámetro con el nombre del equipo.
     */
    public Equipo(String nombre)
    {
        //Al atributo nombre se le asigna el valor del parámetro.
        this.nombre = nombre;
        //Inicializar las referecncias a los 3 jugadores a null.
        jugador1 = null;
        jugador2 = null;
        jugador3 = null;
        //Inicializar el contador de jugadores del equipo a 0.
        contadorJugadores=0;
    }
    
    /**
     * Método que añade un jugador a un equipo, si el equipo no esta completo.
     * Dependiendo de los jugadores que ya hallan en el equipo se asigna a uno 
     * de los tres jugadores que puede tener el equipo.
     * 
     * @param jugador Parámetro que pasa el jugador a añadir al equipo.
     */
    public void addJugador(Jugador jugador)
    {
        //Comprobar si hay hueco con el método equipoCompleto.
        if (equipoCompleto() == false)
        {
            //Dependiendo del total de jugadores que tenga ya el equipo.
            //Se añade al jugador a uno de los 3 huecos disponibles.
            //Cuando se añade el jugador aumenta en 1 el total de jugadores del equipo.
            switch(contadorJugadores)
            {
                //No hay jugadores en el equipo.
                case 0:
                    //Asignar jugador al primer hueco=jugador1.
                    jugador1 = jugador;
                    contadorJugadores++;
                    break;
                //Hay un jugador en el equipo.    
                case 1:
                    //Asignar jugador al segundo hueco=jugador2.
                    jugador2 = jugador;
                    contadorJugadores++;
                    break;
                //Hay dos jugadores en el equipo.    
                case 2:
                    //Asignar jugador al tercer hueco=jugador3.
                    jugador3 = jugador;
                    contadorJugadores++;
                    break;
            }
        }    
        else
        
            System.out.println("Equipo lleno no se pueden añadir jugadores");
    }
    
    /**
     * Método que registra un nuevo jugador y lo añade al equipo.
     * 
     * @param nombre Parámetro que pasa el nombre del jugador.
     * @param sueldo Parámetro que pasa el sueldo del jugador.
     */
    public void addJugador(String nombre, double sueldo)
    {
        //Variable auxliar para almacenar la referencia al nuevo jugador.
        Jugador jugadorAux;
        //Crea un nuevo jugador mediante constructor de la clase jugador con los parámetros pasados.
        jugadorAux = new Jugador(nombre, sueldo);
        //Añade el jugador al equipo.
        addJugador(jugadorAux);
    }
    
    /**
     * Método que devuelve el total de jugadores que tiene el equipo.
     * 
     * @return Devuelve el número de jugadores que tiene el equipo.
     */
    public int cuantosJugadores()
    {
        return contadorJugadores;
    }
    
    /**
     * Método para saber si el equipo esta completo.
     * 
     * @return Devuelve el estado del equipo.
     */
    public boolean equipoCompleto()
    {
        //Si el contador de jugadores es 3, el equipo está completo.
        return contadorJugadores == 3;
    }
    
    /**
     * Método para saber qué jugador es el que más goles ha marcado, el pichichi.
     * 
     * @return Devuelve el nombre del pichichi, si lo hay.
     */
    public String pichici()
    {
        //Variable auxiliar para almacenar la referencia al jugador que más goles tiene.
        Jugador esPichichi;
        //Inicializar a nulo.
        esPichichi = null;
        //El pichichi se obtiene dependiendo del número de jugadores.
        //Asignar a esPichichi la refrencia al jugador con más goles.
        switch(contadorJugadores)
        {
            //No hay jugadores en el equipo.
            case 0: return "No hay pichici ya que no hay jugadores";
            //Hay un jugador en el quipo por lo que tiene que ser el pichichi.
            case 1: 
                {
                    esPichichi = jugador1;
                    break;   
                }
            //Hay dos jugadores en el equipo.
            //Comparar jugador 1 y jugador 2 y asignar a esPichichi el que más goles, si empate esPichichi= null = no hay pichichi.
            //comparar goles jugador mediante getGoles.
            case 2: 
                {
                    if (jugador1.getGoles() > jugador2.getGoles())
                        //Jugador 1 el que más goles.
                        esPichichi = jugador1;
                    else if (jugador1.getGoles() < jugador2.getGoles())
                        //Juador 2 el que más goles.
                        esPichichi = jugador2;
                    else
                        //Empate a goles.
                        esPichichi = null;
                    break;    
                }
            //Hay tres jugadores en el equipo.
            //Comparar J1 y J2 y asignar a esPichichi el que más goles, si empate esPichichi= null = no hay pichichi.
            case 3:
                {
                    if (jugador1.getGoles() > jugador2.getGoles())
                        //Jugador 1 el que más goles.
                        esPichichi = jugador1;
                    else if (jugador1.getGoles() < jugador2.getGoles())
                        //Juador 2 el que más goles.
                        esPichichi = jugador2;
                    else 
                        //Empate a goles.
                        esPichichi = null;
                    //Si ha habido un maximo goleador entre el primero y el segundo.Comparar con el tercer jugador.
                    if (esPichichi != null)
                    {
                        //Si J3 tiene más goles que el que más goles entre J1 y J2
                        if (jugador3.getGoles() > esPichichi.getGoles())
                            esPichichi = jugador3;
                        //Si J3 mismos goles que el que más goles entre J1 y J2    
                        else if (jugador3.getGoles() == esPichichi.getGoles())
                        //Empate a goles.
                            esPichichi = null;                                
                    }
                    //Si J1 y J2 han empatado a goles esPichichi = null = no hay pichichi.
                    //Comparar J3 con J1 o J2 ya que tienen los mismo goles
                    else if (jugador3.getGoles() > jugador1.getGoles())
                        esPichichi = jugador3;
                    //Si J3 tiene menos goles que J1 o J2 no hay pichichi ya que J1 y J2 habrán empatado
                    else
                        esPichichi = null;
                    break;    
                }
        }
        if (esPichichi == null)
            return "No hay pichici, hay empate de goles";
        else
            //devolver el nombre del que más goles
            return "El pichichi es: "+ esPichichi.getNombre();
    }
    
    /**
     * Método para borrar la pantalla.
     */
    public void borrarPantalla()
    {
        System.out.print('\u000C');
    }
    
    /**
     * Método que devuelve una representación textual del equipo.
     * 
     * @return Devuelve un string con la representación del equipo.
     */
    public String toString()
    {
        //var auxiliar para devolver el equipo dependiendo del número de jugadores.
        String jugadoresEquipo;
        //inicializar a null.
        jugadoresEquipo = null;
        switch(contadorJugadores)
        {
            case 0:  jugadoresEquipo = "No ahy jugadores en el equipo";break;
            case 1:
                {
                    System.out.print("Equipo-" + nombre + "\nJugadores:\n" + jugador1.toString());//Para ver por consola.
                    jugadoresEquipo = "Equipo-" + nombre + "\nJugadores:\n" + jugador1.toString();
                    break;
                }
            case 2:
                {
                    System.out.print("Equipo-" + nombre + "\nJugadores:\n" + jugador1.toString() + "\n"+ jugador2.toString());//Para ver por consola.
                    jugadoresEquipo = "Equipo-" + nombre + "\nJugadores:\n" + jugador1.toString() + "\n"+ jugador2.toString();
                    break;
                }
            case 3:
                {
                    System.out.print("Equipo-" + nombre + "\nJugadores:\n" + jugador1.toString() + "\n"+ jugador2.toString() + "\n" + jugador3.toString());//Para ver por consola.
                    jugadoresEquipo = "Equipo-" + nombre + "\nJugadores:\n" + jugador1.toString() + "\n"+ jugador2.toString() + "\n" + jugador3.toString();
                    break;
                }
        } 
        return jugadoresEquipo;
    }
}
