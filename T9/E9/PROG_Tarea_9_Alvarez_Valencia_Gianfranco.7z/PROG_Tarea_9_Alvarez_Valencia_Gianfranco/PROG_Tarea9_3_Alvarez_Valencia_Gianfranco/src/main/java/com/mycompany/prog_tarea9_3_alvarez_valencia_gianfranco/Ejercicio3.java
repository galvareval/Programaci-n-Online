
package com.mycompany.prog_tarea9_3_alvarez_valencia_gianfranco;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Ejercicio 3
 * @author Gianfranco Álvarez Valencia
 * @version 17_04_2022_01
 */
public class Ejercicio3 extends JFrame //implements ActionListener 
{ 
    private JPanel panel; // panel
    private JButton boton;
    private JLabel etiquetaContador;
    private int contadorClicks;
    public Ejercicio3()
    { 
        super.setTitle("Ejercicio3"); // Título de la ventana
        super.setSize(300, 100); // Tamaño de ventana
        this.setLocationRelativeTo(null);// Centrar ventana
        contadorClicks = 0;
        JPanel panel = new JPanel();// Crear panel
        this.getContentPane().add(panel);// Añadir a ventana
        JButton boton = new JButton("Click para aumentar el contador");// Crear boton
        panel.add(boton);// Añadir botón
        JLabel etiquetaContador = new JLabel();// Para mostrar el contador
        etiquetaContador.setText(String.valueOf(contadorClicks));// Establecer el valor inicital del contador
        panel.add(etiquetaContador);// Añadir al panel
        // Funcilalidad del botón
        ActionListener clickBoton = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                contadorClicks += 1;// Aumentar el contador de clicks
                etiquetaContador.setText(String.valueOf(contadorClicks));// Establecer el nuevo valor a mostrar
            }
        };
        boton.addActionListener(clickBoton);// Añadir la funcionalidad al boton
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);// Evitar cerrar en consosla
    }
    
    
    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run()
            {
                new Ejercicio3().setVisible(true);
            }
        });
    }
}
