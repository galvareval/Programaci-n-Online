
package com.mycompany.prog_tarea9_4_alvarez_valencia_gianfranco;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Ejericcio 4
 * @author Gianfranco Álvarez Valencia
 * @version 18_04_2022_01
 */
public class Ejercicio4 extends JFrame
{
    private JTextField cajaNum1;
    private JTextField cajaNum2;
    private JLabel numero1JLabel;
    private JLabel numero2JLabel; 
    private JPanel panel; // panel
    private JButton botonSumar;
    private JButton botonRestar;
    private JButton botonDividir;
    private JButton botonMultiplicar;
    private int resultado; 
    public Ejercicio4()
    { 
        resultado = 0;
        super.setTitle("Ejercicio4"); // Título de la ventana
        super.setSize(400, 170); // Tamaño de ventana
        this.setLocationRelativeTo(null);// Centrar ventana
        JPanel panel = new JPanel();// panel
        this.getContentPane().add(panel);// Añadir a ventana
        panel.setLayout (null);
        JLabel numero1JLabel = new JLabel("Ingresar primer número");// num1
        numero1JLabel.setBounds(10, 10, 200, 30);
        panel.add(numero1JLabel);
        cajaNum1 = new JTextField();
        cajaNum1.setBounds(200, 10, 50, 30);
        panel.add(cajaNum1);
        JLabel numero2JLabel = new JLabel("Ingresar segundo número");// num2
        numero2JLabel.setBounds(10, 40, 200, 30);
        panel.add(numero2JLabel);
        cajaNum2 = new JTextField();
        cajaNum2.setBounds(200, 40, 50, 30);
        panel.add(cajaNum2);
        JButton botonSumar = new JButton("+");
        botonSumar.setBounds(250, 10, 50, 50);
        panel.add(botonSumar);// Añadir botón
        JButton botonRestar = new JButton("-");
        botonRestar.setBounds(300, 10, 50, 50);
        panel.add(botonRestar);// Añadir botón
        JButton botonDividir = new JButton("/");
        botonDividir.setBounds(250, 60, 50, 50);
        panel.add(botonDividir);// Añadir botón
        JButton botonMultiplicar = new JButton("X");
        botonMultiplicar.setBounds(300, 60, 50, 50);
        panel.add(botonMultiplicar);// Añadir botón
        // Escuchas para los botones
        // Suma
        ActionListener suma = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ev){
                if (vacio() == true)
                {   
                    JOptionPane.showMessageDialog(panel, "Campo vacio","Error" , JOptionPane.ERROR_MESSAGE);
                    resetear();
                }
                else
                {    
                    resultado = obtenerNum1() + obtenerNum2();
                    JOptionPane.showMessageDialog(panel, resultado,"Resultado" , JOptionPane.INFORMATION_MESSAGE);
                    resetear();
                }
            }
        };
        botonSumar.addActionListener(suma);
        // Resta
        ActionListener resta = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ev){
                if (vacio() == true)
                {   
                    JOptionPane.showMessageDialog(panel, "Campo vacio","Error" , JOptionPane.ERROR_MESSAGE);
                    resetear();
                }
                else
                {
                    resultado = obtenerNum1() - obtenerNum2();
                    JOptionPane.showMessageDialog(panel, resultado,"Resultado" , JOptionPane.INFORMATION_MESSAGE);
                    resetear();
                }
            }
        };
        botonRestar.addActionListener(resta);
        // Multiplicar
         ActionListener multiplic = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ev){
                if (vacio() == true)
                {   
                    JOptionPane.showMessageDialog(panel, "Campo vacio","Error" , JOptionPane.ERROR_MESSAGE);
                    resetear();
                }
                else
                {    
                    resultado = obtenerNum1() * obtenerNum2();
                    JOptionPane.showMessageDialog(panel, resultado,"Resultado" , JOptionPane.INFORMATION_MESSAGE);
                    resetear();
                }
            }
        };
        botonMultiplicar.addActionListener(multiplic);
        // Dividir
         ActionListener division = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ev){
                if (vacio() == true)
                {   
                    JOptionPane.showMessageDialog(panel, "Campo vacio","Error" , JOptionPane.ERROR_MESSAGE);
                    resetear();
                }
                else
                {    
                    resultado = obtenerNum1() / obtenerNum2();
                    JOptionPane.showMessageDialog(panel, resultado,"Resultado" , JOptionPane.INFORMATION_MESSAGE);
                    resetear();
                }
            }
        };
        botonDividir.addActionListener(division);
        // Escucha para cuando se cierre la ventana
        this.addWindowListener( new WindowAdapter() {
        public void windowClosing( WindowEvent evt ) {
         JOptionPane.showMessageDialog(panel, "Saliendo del programa","Hasta la próxima" , JOptionPane.WARNING_MESSAGE);
        }
        } );
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);// Evitar cerrar en consosla
    }
    /**
     * Méto para comprobar si hay algún valor vacio
     * @return Devuelve un booleano con la comprobación.
     */
    private boolean vacio()
    {
        if (cajaNum1.getText().equals("") || cajaNum2.getText().equals("") )
            return true;
        else
            return false;
    }
    /**
     * Método para obtener el primer número
     * @return Devuelve el primer número
     */
    private int obtenerNum1()
    {
         return  Integer.parseInt(cajaNum1.getText());
    }
    /**
     * Método para obtener el segundo número
     * @return Devuelve el segundo número
     */   
    private int obtenerNum2()
    {
         return  Integer.parseInt(cajaNum2.getText());
    }
    /**
     * Método para resetear los valores de los cuadros de texto.
     */
    private void resetear()
    {
        cajaNum1.setText("");
        cajaNum2.setText("");
    }
    /**
     * Main del programa
     * @param args 
     */
    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run()
            {
                new Ejercicio4().setVisible(true);
            }
        });
    }
}
