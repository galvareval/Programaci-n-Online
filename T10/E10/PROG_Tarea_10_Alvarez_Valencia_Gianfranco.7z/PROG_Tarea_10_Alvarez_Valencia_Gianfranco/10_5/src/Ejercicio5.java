import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 * Ejericcio 5
 * @author Gianfranco Álvarez Valencia
 * @version 07_05_2022_
 */
public class Ejercicio5 extends JFrame
{
    //conexion BBDD
    public String db;
    public String url;
    public String user;
    public String pass;
    public Connection con;
    // GRafico botones y textos
    private JTextField cajaTitulo;
    private JTextField cajaAutor;
    private JTextField cajaEditorial;
    private JTextField cajaFechaPubli;
    private JTextField cajaIsbn;
    private JLabel tituloJLabel;
    private JLabel autorJLabel; 
    private JLabel editorialJLabel;
    private JLabel fechaPubliJLabel;
    private JLabel isbnJLabel;
    private JPanel panel; // panel
    private JButton nuevo;
    private JButton guardar;
    private JButton salir;
    private JScrollPane scroll;
    /**
     * Ejercicio 5
     */
    public Ejercicio5()
    { 
        // Conexion BBDD
        db = "biblioteca";
        url = "jdbc:mysql://localhost:3306/" + db + "?serverTimezone=UTC";
        user = "root";
        pass = "pepe";
        con = null;
        
        super.setTitle("Ejercicio5"); // Título de la ventana
        super.setSize(570, 970); // Tamaño de ventana
        this.setLocationRelativeTo(null);// Centrar ventana
        JPanel panel = new JPanel();// panel
        this.getContentPane().add(panel);// Añadir a ventana
        panel.setLayout (null);
        
        JLabel tituloJLabel = new JLabel("Título");// titulo
        tituloJLabel.setBounds(10, 10, 100, 30);
        panel.add(tituloJLabel);
        cajaTitulo = new JTextField();
        cajaTitulo.setBounds(150, 10, 200, 30);
        panel.add(cajaTitulo);
        
        JLabel autorJLabel = new JLabel("Autor");// autor
        autorJLabel.setBounds(10, 50, 100, 30);
        panel.add(autorJLabel);
        cajaAutor = new JTextField();
        cajaAutor.setBounds(150, 50, 200, 30);
        panel.add(cajaAutor);
        
        JLabel editorialJLabel = new JLabel("Editorial");// editorial
        editorialJLabel.setBounds(10, 90, 200, 30);
        panel.add(editorialJLabel);
        cajaEditorial = new JTextField();
        cajaEditorial.setBounds(150, 90, 200, 30);
        panel.add(cajaEditorial);
        
        JLabel fechaPubliJLabel = new JLabel("Fecha publicación");// fechaPubli
        fechaPubliJLabel.setBounds(10, 130, 200, 30);
        panel.add(fechaPubliJLabel);
        cajaFechaPubli = new JTextField();
        cajaFechaPubli.setBounds(150, 130, 200, 30);
        panel.add(cajaFechaPubli);
        
        JLabel isbnJLabel = new JLabel("ISBN");// isbn
        isbnJLabel.setBounds(10, 170, 200, 30);
        panel.add(isbnJLabel);
        cajaIsbn = new JTextField();
        cajaIsbn.setBounds(150, 170, 200, 30);
        panel.add(cajaIsbn);
        
        JButton botonNuevo = new JButton("Nuevo");
        botonNuevo.setBounds(10, 250, 80, 50);
        panel.add(botonNuevo);// Añadir botón
        
        JButton botonGuardar = new JButton("Guardar");
        botonGuardar.setBounds(150, 250, 80, 50);
        panel.add(botonGuardar);// Añadir botón
        
        JButton botonSalir = new JButton("Salir");
        botonSalir.setBounds(350, 250, 80, 50);
        panel.add(botonSalir);// Añadir botón
        
        // Tabla
        /*Object [] columnas = {"TITULO", "AUTOR", "EDITORIAL", "FECHA PUBLICACIÓN", "ISBN"};
        Object[][] filas = { {"1 ", 80, 80, 80, 240},
                {"John", 70, 80, 90, 240},
                {"Sue", 70, 70, 70, 210},
                {"Jane", 80, 70, 60, 210},
                {"Joe", 80, 70, 60, 210}
        };
            JTable table = new JTable(filas, columnas);
            table.setBounds(10,350, 500, 300);
            //panel.add(table.getTableHeader(),BorderLayout.NORTH);
            JScrollPane scp = new JScrollPane();
            scp.setBounds(10,350,500,300);
            scp.add(table);
            panel.add(scp);*/
        // Escuchas para los botones
        // Botón guardar
        ActionListener guardar = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ev){
                if (vacio() == true)
                {   
                    JOptionPane.showMessageDialog(panel, "Hay campos sin rellenar","Error" , JOptionPane.ERROR_MESSAGE);
                    resetear();
                }
                else
                {   
                    try {
                        // Crear la sentencia insert a partir de los datos de los campos
                        String datos = "INSERT INTO LIBRO VALUES"
                                + "('" + obtenerIsbn() + "','" + obtenerTitulo() + "','" + obtenerAutor() + "','" + obtenerEditorial() + "','" + obtenerFechaPubli() + "');";
                        Statement s = con.createStatement();
                        System.out.println("Datos insertados: " + datos + "" + s);
                        s.executeUpdate(datos);
                        JOptionPane.showMessageDialog(panel, "Datos guardados","Datos guardados" , JOptionPane.INFORMATION_MESSAGE);
                        resetear();
                        limpiarTabla();
                        crearTabla();
                    } catch (SQLException ex) {
                        Logger.getLogger(Ejercicio5.class.getName()).log(Level.SEVERE, null, ex);
                        resetear();
                    }
                }
            }
        };
        botonGuardar.addActionListener(guardar);
        
        // Botón nuevo
        ActionListener nuevo = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ev){
                resetear();
            }
        };
        botonNuevo.addActionListener(nuevo);
        
        // Botón salir
         ActionListener salir = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ev){
                cerrrarCoexion();
                System.out.println("Coexiónc cerrada");
                System.exit(0);
            }
        };
        botonSalir.addActionListener(salir);
        
        // Escucha para cuando se cierre la ventana
        this.addWindowListener( new WindowAdapter() {
        public void windowClosing( WindowEvent evt ) {
         JOptionPane.showMessageDialog(panel, "Saliendo del programa","Hasta la próxima" , JOptionPane.WARNING_MESSAGE);
        }
        } );
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);// Evitar cerrar en consosla
    }
    /**
     * Método para establecer la conexión.
     */
    public void conectar()
    {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(this.url,this.user,this.pass);
            
        } catch (SQLException  e) 
        {
            System.out.println("SQL Exception: "+ e.toString());
        } 
        catch (ClassNotFoundException cE) 
        {
            System.out.println("Excepción: "+ cE.toString());
        }
    }
    /**
     * Método para cerrar la conexion a la base de datos.
     */
    public void cerrrarCoexion()
    {
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Ejercicio5.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * Méto para comprobar si hay algún valor vacio
     * @return Devuelve un booleano con la comprobación.
     */
    private boolean vacio()
    {
        if (cajaIsbn.getText().equals("") || cajaTitulo.getText().equals("") || cajaAutor.getText().equals("") || cajaEditorial.getText().equals("") || cajaFechaPubli.getText().equals("") )
            return true;
        else
            return false;
    }
    /**
     * Método para obtener el autor
     * @return Devuelve el autor
     */
    private String obtenerTitulo()
    {
         return  cajaTitulo.getText();
    }
    
    /**
     * Método para obtener el autor
     * @return Devuelve el autor
     */   
    private String obtenerAutor()
    {
         return  cajaAutor.getText();
    }
    
    /**
     * Método para obtener el editorial
     * @return Devuelve el autor
     */   
    private String obtenerEditorial()
    {
         return  cajaEditorial.getText();
    }
    
    /**
     * Método para obtener la fecha publicacion
     * @return Devuelve la fecha publicacion
     */   
    private String obtenerFechaPubli()
    {
         return  cajaFechaPubli.getText();
    }
    
    /**
     * Método para obtener el ISBN
     * @return Devuelve el ISBN
     */   
    private String obtenerIsbn()
    {
         return  cajaIsbn.getText();
    }
    
    /**
     * Método para resetear los valores de los cuadros de texto.
     */
    private void resetear()
    {
        cajaTitulo.setText("");
        cajaAutor.setText("");
        cajaEditorial.setText("");
        cajaFechaPubli.setText("");
        cajaIsbn.setText("");
    }
    /**
     * crear tabla
     */
    public void crearTabla()
    {
        //sql
        try {
            Statement stTabla = con.createStatement();
            ResultSet resT = stTabla.executeQuery("SELECT * FROM libro;");
            DefaultTableModel modelo = new DefaultTableModel();
            JTable tabla = new JTable(modelo);
            //Columnas
            modelo.addColumn("ISBN");
            modelo.addColumn("TITULO");
            modelo.addColumn("AUTOR");
            modelo.addColumn("EDITORIAL");
            modelo.addColumn("FECHA PUBLICACIÓN");
            // REsultado consulta
            while(resT.next())
            {
                // Crear array de cada una de las fialas de la talba
                Object[] fila = new Object[5];
                for(int i=0;i<5;i++)
                    fila[i] = resT.getObject(i+1);
                modelo.addRow(fila);
            }
            scroll = new JScrollPane(tabla);
            this.getContentPane().add(scroll,BorderLayout.SOUTH);
        } catch (SQLException ex) {
            Logger.getLogger(Ejercicio5.class.getName()).log(Level.SEVERE, null, ex);
        };  
    }
    /**
     * Método para refrescar la tabla al aádir
     */
    public void limpiarTabla()
    {
        
        scroll.removeAll();
        scroll.repaint();
        super.setSize(570, 970); // Tamaño de ventana 
    }
    /**
     * Main del programa
     * @param args 
     */
    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run()
            {
                Ejercicio5 conex = new Ejercicio5();
                conex.setVisible(true);
                conex.conectar();
                conex.crearTabla();
            }
        });
    }
}