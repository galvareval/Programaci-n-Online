//import com.sun.jdi.connect.spi.Connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * Ejercicio 2
 * @author gianf
 */
public class Ejer2_2
{
    public String db;
    public String url;
    public String user;
    public String pass;
    public Connection con;
    /**
     * Constructor establecer parametros de la conexión.
     */
    public Ejer2_2() 
    {
        db = "ventas";
        url = "jdbc:mysql://localhost:3306/" + db + "?serverTimezone=UTC";
        user = "root";
        pass = "pepe";
        con = null;
    }
    /**
     * Método para establecer la conexión.
     */
    public void conectar()
    {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(this.url,this.user,this.pass);
            
        } catch (SQLException  e) 
        {
            System.out.println("SQL Exception: "+ e.toString());
        } 
        catch (ClassNotFoundException cE) 
        {
            System.out.println("Excepción: "+ cE.toString());
        }
    }
    /**
     * Método para consultar los suministradores
     */
    public void consultaSum()
    {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM SUMINISTRADORES;");
            int contRs =0;
            while(rs.next()){
                System.out.println("\tRegistro: " + contRs);
                System.out.println("Ident: " + rs.getString(1)); 
                System.out.println("Suministrador: " + rs.getString(2)); 
                System.out.println("Dirección: " + rs.getString(3)); 
                System.out.println("Ciudad: " + rs.getString(4));
                System.out.println("Prov: " + rs.getString(5));
                System.out.println("CP: " + rs.getString(6));
                contRs++;
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Ejer2_2.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    /**
     * Método para consultar los cafes
     */
    public void consultaCaf()
    {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM CAFES;");
            int contRs =0;
            while(rs.next()){
                System.out.println("\tRegistro: " + contRs);
                System.out.println("NOMBRE_CAFE: " + rs.getString(1)); 
                System.out.println("SUMI_ID: " + rs.getString(2)); 
                System.out.println("PRECIO: " + rs.getString(3)); 
                System.out.println("VENTAS: " + rs.getString(4));
                System.out.println("ACUMULADO: " + rs.getString(5));
                contRs++;
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Ejer2_2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * Método para insertar en la tabla suministradores
     */
    public void instertarDatosSum()
    {
        try {
            String datos = "INSERT INTO SUMINISTRADORES VALUES"
                    + " (101, 'Coffee-Imp', 'Pol. Ind', 'Getafe', 'Mad', 28280),"
                    + " (49, 'La Superior', 'Lepanto 23', 'Rianza', 'Seg', 40546),"
                    + " (150, 'Kaffe', 'Nueva 34', 'Baeza', 'Jaén', 23375);";      
            Statement s = con.createStatement();
            s.executeUpdate(datos);
            
        } catch (SQLException ex) {
            Logger.getLogger(Ejer2_2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * Método apra insetar datos en la tabla cafes.
     */
    public void instertarDatosCaf()
    {
        try {
            String datos = "INSERT INTO CAFES VALUES"
                    + " ('Colombia', 101, 7.99, 0, 0),"
                    + " ('Brasil', 49, 8.99, 0, 0),"
                    + " ('Espresso', 150, 9.99, 0, 0),"
                    + " ('Colombia Descaf', 101, 8.99, 0, 0),"
                    + " ('Brasil Descaf', 49, 9.99, 0, 0);";    
            Statement s = con.createStatement();
            s.executeUpdate(datos);
            
        } catch (SQLException ex) {
            Logger.getLogger(Ejer2_2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * Método para actualizar las ventas semanales y el acumulado pasado por parámetro
     * @param nomCafe nombre del tipo de cafe a aactualizar
     * @param cantidadCafe cantidad de cafe vendida a la semana
     */
    public void ventasSemanalesRestar(String nomCafe, int cantidadCafe)
    {
        // Para almacenar el acumulado actual
        int acumulado = 0;
        try {
            con.setAutoCommit(false);
            //Consulta para obtener el acumulado actual
            String consulta = "SELECT ACUMULADO FROM CAFES WHERE NOMBRE_CAFE = ? ";
            PreparedStatement psAcum = con.prepareStatement(consulta);
            psAcum.setString(1, nomCafe);
            // Ejecutar consulta y almacenar en resulset
            ResultSet results = psAcum.executeQuery();
            while (results.next())
            {
                //System.out.println("Prueba: " +  results.getInt(1));
                // ALmacenar el valor de acumulado para sumarlo con las ventas semanales
                    acumulado = results.getInt(1); 
            }
            // Actualizar las ventas semanales
            PreparedStatement ps = con.prepareStatement("UPDATE CAFES SET VENTAS = ? WHERE NOMBRE_CAFE = ?;");
            ps.setInt(1, cantidadCafe);
            ps.setString(2, nomCafe);
            ps.executeUpdate();
            // Actulizar el acumulado; lo que ya habia acumulado más las ventas semanales
            PreparedStatement psTot = con.prepareStatement("UPDATE CAFES SET ACUMULADO = ? WHERE NOMBRE_CAFE = ?;");
            psTot.setInt(1, acumulado - cantidadCafe);
            psTot.setString(2, nomCafe);
            psTot.executeUpdate();
            //hacer Comit
            con.commit();
        } catch (SQLException ex) {
            Logger.getLogger(Ejer2_2.class.getName()).log(Level.SEVERE, null, ex);
            try {
                con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(Ejer2_2.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
    }
    /**
     * Método para cerrar la conexion a la base de datos.
     */
    public void cerrrarCoexion()
    {
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Ejer2_2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * Método main
     * @param args 
     */
     public static void main(String args[])
    {
        Ejer2_2 conexEjer2_2 = new Ejer2_2();
        conexEjer2_2.conectar();
        // Compobar el acceso concurrente
        for(int i = 1; i <= 100000; i++)
        {
            conexEjer2_2.ventasSemanalesRestar("Colombia", 1000000 + i);
        }
        System.out.println("Fin programa");
        conexEjer2_2.cerrrarCoexion();
    }
     /*
     Para comprobar el acceso concurrente he creado este porgrama ejer2_2 que en el update resta las ventas pasadas por parámetro del acumulado en el bucle.
     En el ejercicio anterior se suman ventas en un bucle al acumulado.
     Al ejecutar los dos porgramas contra ma misma base de datos y ver las conexiones desde el getrode conexiones de mysql no se ven bloqueos
     se van ejecutando las instrucciones. 
     */
}