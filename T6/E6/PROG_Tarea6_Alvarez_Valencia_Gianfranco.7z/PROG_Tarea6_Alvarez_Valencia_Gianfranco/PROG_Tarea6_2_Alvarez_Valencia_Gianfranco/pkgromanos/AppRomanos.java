package pkgromanos;
import java.util.Scanner;//import para usar entrada por teclado.
/**
 * Esta clase controla la ejecución del programa.
 * El usuario puede pasar la información de los números romanos a convertir de dos maneras.
 * De forma Masiva(M), en la que se leeran los romanos por teclado y se 
 *  almacenarán en un Array para pasarlos al gestor de romanos.
 * De forma Individual(I), se leera el romano y seguidamente se pasará al gestor.
 * Las respuestas leidas por teclado pueden ser tanto MAYÚSCULAS como minúsculas.
 * Se da por echo que los números romanos pasados existen en la tabla.
 * No se pueden repetir los números romanos pasados.
 * @author (Gianfranco Álvarez) 
 * @version (01_21_02_2022)
 */
public class AppRomanos
{
    public static void main(String[] args)
    {
        // Declarar variables.
        Scanner teclado;
        GestorRomanos listaRomanos;
        int cantidadNumeros;
        char tipoCarga;
        String [] arrayRomanos;
        // Romano leido por teclado
        String addRomano;
        // Inicializar variables.
        teclado = new Scanner(System.in);
        listaRomanos = new GestorRomanos();
        cantidadNumeros = 0;
        addRomano = "";
        // Preguntar al usuario el número de romanos a convertir y leer la respuesta.
        System.out.println("¿Cuántos números desea añadir?");
        cantidadNumeros = teclado.nextInt();
        // Preguntar como quiere hacer la carga de los números, leer la respuesta y convertirla a mayuscula.
        System.out.println("¿Cómo quieres realizar la carga? [Masiva(M)/Individual(I)]");
        tipoCarga = Character.toUpperCase(teclado.next().charAt(0));
        // Segun la opción tecleada.
        switch(tipoCarga)
        {
            case 'I' ://Carga individual.
                {
                    for (int i = 0;i < cantidadNumeros;i++)
                    {
                        System.out.println("Introduzca el número romano(" + (i+1) + "/" + cantidadNumeros + ")");
                        // Inicializar teclado en cada interacción, de lo contrario no funciona nextLine.
                        teclado = new Scanner(System.in);
                        // Leer desde teclado.
                        addRomano = teclado.nextLine();
                        // Pasar los datos al gestor en mayúscula ya que la tabla tiene los valores en mayúsula.
                        listaRomanos.añadirRomano(addRomano.toUpperCase());
                    }
                    // Mostrar la lista gráficamente.
                    listaRomanos.escribirListaArabigos();
                    break;
                }
            case 'M' :// Carga masvia.
                {
                    // Crear un array con la dimensión de la cantidad de romanos que se pasarán.
                    arrayRomanos = new String[cantidadNumeros];
                    System.out.println("Introduzca los números romanos, fin para terminar");
                    // Para recorrer el array y asignar los valores leidos por teclado. 
                    int k = 0;
                    // Usar equalsIgnoreCase para que la respuesta nosea case sensitive.
                    do
                    {
                        // Inicializar teclado en cada interacción, de lo contrario no funciona nextLine.
                        teclado = new Scanner(System.in);
                        addRomano = teclado.nextLine();
                        // Si la respuesta NO es fin y hay sitio en el array de romanos.
                        if (!addRomano.equalsIgnoreCase("FIN") && (k <cantidadNumeros))
                            {
                                //Añadir el romano en mayśuculas para poder usar la tabla.
                                arrayRomanos[k] = addRomano.toUpperCase();
                                k++;
                            }
                    }
                     while (!addRomano.equalsIgnoreCase("FIN")); 
                    // Pasar los datos al gestor
                    listaRomanos.añadirRomanos(arrayRomanos);
                    // Mostrar la lista gráficamente.
                    listaRomanos.escribirListaArabigos();
                    break;
                }
            default : System.out.println("Opción incorrecta");
        }
        
    }
}
