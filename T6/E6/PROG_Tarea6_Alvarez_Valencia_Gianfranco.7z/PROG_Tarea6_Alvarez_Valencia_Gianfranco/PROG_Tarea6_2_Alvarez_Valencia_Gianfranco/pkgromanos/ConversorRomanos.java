package pkgromanos;
import java.util.HashMap;
/**
 * Esta clase sirve para convertir un número romano en uno arábigo.
 * 
 * @author (Gianfranco Álvarez) 
 * @version (01_19_02_2022)
 */
public class ConversorRomanos
{
    // Atributos talba HashMap
    HashMap<String, Integer> tabla;
    /**
     * Constructor de objetos de la  clase ConversorRomanos.
     * Inicializa la tabla.
     */
    public ConversorRomanos()
    {
        // Crear la tabla
        tabla = new HashMap<String, Integer>();
        inicializar();
    }

    /**
     * Método para incializar la tabla.
     * 
     */
    private void inicializar()
    {
        // Inicializar las claves con sus valores.
        tabla.put("M",1000);
        tabla.put("D",500);
        tabla.put("C",100);
        tabla.put("L",50);
        tabla.put("X",10);
        tabla.put("V",5);
        tabla.put("I",1);
    }
    
    /**
     * Método para convertir un número romano en uno arábigo.
     * 
     * @param nRomano Pasa un número romano a convertir.
     * @return Devuelve el número arábigo correspoendiente al romano.
     */
    public int convertir(String romano)
    {
        // Para almacenar la suma resultado del valor de los números romanos pasados.
        int resultado = 0;
        // Parqa almacenar la conversion de caracter a String.
        String valorCaracter;
        for(int i = 0;i < romano.length();i++)
        {
            // Convertir el caracter a String para poder usar la tabla.
            valorCaracter = String.valueOf(romano.charAt(i));
            // Obtener el valor del carácter y sumarlo al resultado.
            resultado += tabla.get(valorCaracter);
        }
        return resultado;
    }
}
