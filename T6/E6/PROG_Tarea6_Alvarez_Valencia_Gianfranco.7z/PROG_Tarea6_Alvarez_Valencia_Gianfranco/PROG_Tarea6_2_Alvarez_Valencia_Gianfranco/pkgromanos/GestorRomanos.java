package pkgromanos;
//import java.util.HashMap;
import java.util.TreeMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Iterator;
import javax.swing.JOptionPane;
/**
 * Esta clase representa a través de un map la serie de números arábigos estableciendo una asociación entre
 * la clave (el número arábigo) y su número romano asociado.
 * 
 * @author (Gianfranco Álvarez) 
 * @version (01_19_02_2022)
 */
public class GestorRomanos
{
    // Atributos talba HashMap
    TreeMap<Integer, String> listaArabigos;
    ConversorRomanos conversor;
    /**
     * Constructor de objetos de la  clase ConversorRomanos.
     * 
     */
    public GestorRomanos()
    {
        // Nuevo objeto de Converromanos para poder convertir.
        conversor = new ConversorRomanos();
        // Nuevo obejto TreeMap.
        listaArabigos = new TreeMap<Integer,String>();
        
    }

    /**
     * Método para añadir números romanos.
     * 
     * @param romano Para pasar el romano a añadir.
     */
    public void añadirRomano(String romano)
    {
        // Añadir al TreeMap clave = la conversion del romano a Integer, valor el String del número romano.
        listaArabigos.put(conversor.convertir(romano),romano);
        
    }
    
    /**
     * Método para añadir un conjunto de números romanos al map a partir de un Array.
     * 
     * @param listaRomanos Array tipo String para pasar el conjunto de númernos romanos.
     */
    public void añadirRomanos(String[] listaRomanos)
    {
        for(int i = 0;i < listaRomanos.length;i++)
        {
            if(listaRomanos[i] != null)// Controlar que no se añadan valores nulos.
                listaArabigos.put(conversor.convertir(listaRomanos[i]),listaRomanos[i]);
        }
    }
    
    /**
     * Método que muestra graficamente el map.
     * 
     */
    public void escribirListaArabigos()
    {
        // Obtener la relación de los números arábigos y romanos mediante método toString.
        // Mostrar el resultado mediante un cuadro de dialgo.
        JOptionPane.showMessageDialog(null, toString(),
                                "Lista arábigos",
                                JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Método que devuelve un string con la relación de los números romanos arábigos.
     * 
     * @return Devuelve una cadena con la relación de los números.
     */
    public String toString()
    {
        // Para almacenar el resultado.
        String resultado = "Escribir lista arábigos";
        // Iterar el map y acumular los valores arábigos y su correspondiente romano.
        for(Map.Entry<Integer,String> lista: listaArabigos.entrySet())
        {
            resultado += "\n" + lista.getKey() + " - " + lista.getValue();
        }
        return resultado;
    }
}
