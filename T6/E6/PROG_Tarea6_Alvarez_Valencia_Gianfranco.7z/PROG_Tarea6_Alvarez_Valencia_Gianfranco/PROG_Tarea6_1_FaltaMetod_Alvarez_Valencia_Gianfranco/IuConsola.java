import java.util.Scanner;//import para usar entrada por teclado.
import java.util.StringTokenizer;
import java.util.ArrayList;

/**
/**
 * Clase que representa la interfaz de texto del programa.
 * 
 * @author (Gianfranco Álvarez) 
 * @version (01_17_02_2022)
 */
public class IuConsola
{
    // Atributos
    private static String FIN = "FIN";
    Scanner teclado;
    ListaPersonas listaPersonas;
    /**
     * Constructor de objetos de la clase IUConsola
     */
    public IuConsola ()
    {
        // Inicializar atributos.
        listaPersonas = new ListaPersonas();
        teclado = new Scanner(System.in);
    }

    /**
     * Meétodo main para inciar el programa.
     */
    public static void main(String[] args)
    {
        // Crear objeto para usar método inciar.
        IuConsola inicio = new IuConsola(); 
        inicio.iniciar();
    }
    /**
     * Método inciar, desde el que se leen los datos que quiera pasar
     * el usuario, hasta que pase el dato: "FIN".
     */
    public void iniciar()
    {
        // Inicilizar respuesta de teclado.
        String res = "";
        System.out.println("Introduzca en cada línea los datos de una persona: \n La coma (,) es el separador entre los datos.\n Formato: <nombre y apellidos>, <estado civil en mayúsculas>, <dia>, <mes>, <año>\nPara terminar, teclee FIN");
        // Usar equalsIgnoreCase para que la respuesta nosea case sensitive.
        do
        {   // Leer respuesta de teclado.
            res = teclado.nextLine();
            // Si la respuesta NO es fin.
            if (!res.equalsIgnoreCase(FIN))
                // Añadir persona a la lista.
                listaPersonas.addPersona(crearPersona(res));
        }
        // Repetir hasta que la respuesta sea fin.
        while (!res.equalsIgnoreCase(FIN));
        // Mostrar personas inicialmente en la lita.
        System.out.println("Personas inicialmente en la lista");
        listaPersonas.printPersonas();
        // Ver personas que cunplen en un mes pasado por teclado.
        System.out.println("Introduce un mes (numéro) para ver quienes cumplen años en ese mes:");
        res = teclado.nextLine();
        // Pasar el string leido por teclado a Integer.
        System.out.println("Hay " + listaPersonas.cumplenEnMes(Integer.valueOf(res)) + " personas que cumplen en el mes " + res);
        // Mostrar personas divorciadas.
        System.out.println("\nHay " + listaPersonas.cuantosDivorciados() + " personas divorciadas");
        // Mostrar la persona más joven
        // Crear un objeto (personaMasJoven)Persona para almacenar la persona más joven
        Persona personaMasJoven;
        // Inicializar a null
        personaMasJoven = null;
        // Almacenar la persona más joven
        personaMasJoven = listaPersonas.masJoven();
        System.out.println("\nLa persona más joven es:\n"+ personaMasJoven.toString());
        // Mostrar personas solteras
        System.out.println("\n****Lista de solteros****");
        // Crear un objeto(listaSolteros) de ListaPersonas para almacenar los solteros.
        ListaPersonas listaSolteros = new ListaPersonas();
        // Crear un Arraylist(listaDeSolteros) para almacenar los solteros devueltos al borrarlos con el método.
        ArrayList<Persona> listaDeSolteros = new ArrayList<Persona>();
        listaDeSolteros = listaPersonas.borrarSolteros();
        // Pasar los solteros del ArrayList al objeto ListaSolteros.
        for (Persona per : listaDeSolteros)
            listaSolteros.addPersona(per);
        // Imprimir la lista de solteros
        listaSolteros.printPersonas();
        // Personas en la lista después de borrar los solteros.
        System.out.println("****Personas en la lista después de borrar los solteros****");
        listaPersonas.printPersonas();
    }
    
    /**
     * Método para crear un objeto Persona a partir de los datos pasados por una cadena.
     * 
     * @param datos String que contiene los datos para crear la persona.
     * @return Devuelve la persona creada.
     */
    private Persona crearPersona(String datos)
    {
        // Para almacenar la persona a crear.
        Persona nuevaPersona = null;
        // Token para almacenar los datos del string separados por ",".
        StringTokenizer tokens = new StringTokenizer(datos, ",");
        // Numero de tokens para dimension del Array que contendrá los datos.
        int nDatos = tokens.countTokens();
        // Para recorrer el array de datos de la persona.
        int i = 0;
        // Array String de datos de la persona con dimensión = Numero de tokens.
        String [] datosPersona = new String[nDatos];
        // Para almacenar los datos obetnidos del String pasado.
        String nombre;
        EstadoCivil estadoCivil;
        int dia;
        int mes;
        int año;
        // Pasar los tokens a el Array.
        while(tokens.hasMoreTokens())
        {
            String cadena = tokens.nextToken();
            datosPersona[i] = cadena;
            i++;
        }
        // Inicialiazr los datos de las personas a partir del Array
        nombre = datosPersona[0];
        // obtener el enumerado.
        estadoCivil = EstadoCivil.valueOf(datosPersona[1]);
        dia = Integer.valueOf(datosPersona[2]);
        mes = Integer.valueOf(datosPersona[3]);
        año = Integer.valueOf(datosPersona[4]);
        // Crear nueva persona a partir de los datos.
        nuevaPersona = new Persona(dia,mes,año,nombre,estadoCivil);
        return nuevaPersona;
    }
    }
