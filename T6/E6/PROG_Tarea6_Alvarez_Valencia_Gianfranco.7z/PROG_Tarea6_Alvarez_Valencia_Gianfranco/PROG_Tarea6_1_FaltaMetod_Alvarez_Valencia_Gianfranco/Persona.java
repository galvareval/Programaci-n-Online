import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
/**
 * Esta clase guarda los datos de una persona.
 * 
 * @author (Gianfranco Álvarez Valencia) 
 * @version (01_17_02_2022)
 */
public class Persona
{
    // Atributos
    private String nombre;
    private EstadoCivil estadoCivil;
    private Calendar fechaNac;  
    /**
     * Constructor de objetos para la clase Persona.
     * 
     * @param dia para pasar el día que formará parte de la fecha.
     * @param mes para pasar el día que formará parte de la fecha.
     * @param año para pasar el día que formará parte de la fecha.
     * @param estadoCivil para pasar el estado civil.
     */
    public Persona(int dia,int mes,int año,String nombre,EstadoCivil estadoCivil)
    {
        //Inicializar atributos.
        this.nombre = nombre;
        this.estadoCivil = estadoCivil;
        // Restar 1, empieza a contar los meses en 0.
        asignarFecha(dia,mes - 1,año);
    }
    
    /**
     * Método para crear la fecha a partir de los datos de la persona.
     */
    private void asignarFecha(int dia,int mes,int año)
    {
        // Crear un objeto para las fechas.
        GregorianCalendar fecha = new GregorianCalendar();
        // Setear a partir de los parámetros.
        fecha.set(GregorianCalendar.YEAR, año);
        fecha.set(GregorianCalendar.MONTH, mes);
        fecha.set(GregorianCalendar.DATE, dia);
        // Asignar al atributo.
        fechaNac = fecha;
    }

    /**
     * Método que devuelve el nombre con formato primera inicial del nombre
     * seguida de un punto(.) un blanco(" ") y los apellidos.
     * 
     * @Return  Devuelve el nombre formateado.
     */
    public String getNombre()
    {
        // Para almacear las "palabras" divididas.
        String[] dividirNombre = nombre.split(" ");
        // Devolver con el formato, primer apellido; pos = 1.
        return "" + nombre.charAt(0) + ". " + dividirNombre[1];
    }
    
    /**
     * Método que devuelve el estado civil de una persona.
     * 
     * @return Devuelve el objeto estado civil.
     */
    public EstadoCivil getEstadoCivil()
    {
        return estadoCivil;
    }
    
    /**
     * Método que devuelve el estado civil de una persona como un String.
     * 
     * @return Devuelve el estado civil como string.
     */
    public String getEstadoToString ()
    {
        return estadoCivil.toString();
    }
    
    /**
     * Método que devuelve la fecha de nacieminto de una persona.
     * @return Devuelve la fecha de nacieminto de una persona.
     */
    public Calendar getFechaNacimiento()
    {
      return fechaNac;
    }
    
    /**
     * Método que devuelve la fecha de nacieminto de una persona.
     * @return Devuelve la fecha de nacieminto de una persona.
     */
    public String getFecha()
    {
        // Crear el formato con el que hay que devolver la fecha.
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        //System.out.println(formatoFecha.format(fechaNac.getTime()));
        return formatoFecha.format(fechaNac.getTime());
    }
    
    /**
     * Método que compara el objeto persona con otro pasado por parámetro
     * devuelve true si la persona pasada por parámetro es mayor.
     */
    public boolean masJovenQue(Persona persona)
    {
        // Comparar las fechas de nacimeinto.
        return fechaNac.after(persona.getFechaNacimiento());
    }
    
    /**
     * Método que devulve la representación textual de la persona.
     * 
     */
    public String toString()
    {
        // Para almacenar el resultado.
        String resultado = "";
        resultado += "\n\tNombre:          " + getNombre() + "\n\tEstado Civil:    " + getEstadoToString() + "\n\tFecha nac:       " + getFecha() + "\n";
        //System.out.println(resultado);
        return resultado;
    }
}
