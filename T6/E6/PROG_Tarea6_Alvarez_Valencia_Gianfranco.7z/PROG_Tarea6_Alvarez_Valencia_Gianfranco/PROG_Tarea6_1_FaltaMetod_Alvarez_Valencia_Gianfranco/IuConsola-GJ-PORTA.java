import java.util.Scanner;//import para usar entrada por teclado.
import java.util.StringTokenizer;

/**
/**
 * Clase que representa la interfaz de texto.
 * 
 * @author (Gianfranco Álvarez) 
 * @version (01_17_02_2022)
 */
public class IuConsola
{
    // instance variables - replace the example below with your own
    private static String FIN = "FIN";
    Scanner teclado;
    ListaPersonas listaPersonas;
    /**
     * Constructor for objects of class IUConsola
     */
    public IuConsola ()
    {
        ListaPersonas listaPersonas = new ListaPersonas();
        teclado = null;
        teclado = new Scanner(System.in);
    }

    /**
     * Meétodo main para inniar el programa.
     */
    public static void main(String[] args)
    {
        IuConsola inicio = new IuConsola(); 
        inicio.iniciar();
    }
    /**
     * Método inciar, desde el que se leen los datos que quiera pasar
     * el usuario, hasta que pase el dato: "FIN".
     */
    public void iniciar()
    {
        //Persona adPer;
        String res = "";
        System.out.println("Introduzca en cada línea los datos de una persona: \n La coma (,) es el separador entre los datos.\nFormato: <nombre y apellidos>, <estado civil en mayúsculas>, <dia>, <mes>, <año>\nPara terminar, teclee FIN");
        do
        {   
            res = teclado.nextLine();
            System.out.println(res);
            if (!res.equals(FIN))
                {
                //crearPersona(res).toString();
                //adPer = crearPersona(res);
                //listaPersonas.addPersona(adPer);
                listaPersonas.addPersona(crearPersona(res));
                }
        }
        while (!res.equals(FIN));
    }
    
    /**
     * Método para crear la persona
     */
    private Persona crearPersona(String datos)
    {
        Persona nuevaPersona = null;
        // Token para almacenar los datos.
        StringTokenizer tokens = new StringTokenizer(datos, ",");
        // Numero de tokens para dimension del array.
        int nDatos = tokens.countTokens();
        // çpara recorrer el array de datos de la persona.
        int i = 0;
        // Array de datos de la perosna.
        String [] datosPersona = new String[nDatos];
        // Para almacenar los datos de la persona.
        String nombre;
        EstadoCivil estadoCivil;
        int dia;
        int mes;
        int año;
        // Pasar los tokens a un array.
        while(tokens.hasMoreTokens())
        {
            String cadena = tokens.nextToken();
            datosPersona[i] = cadena;
            i++;
        }
        // Inicialiazr los datos de las personas a partir del array
        nombre = datosPersona[0];
        // obtener el enumerado.
        estadoCivil = EstadoCivil.valueOf(datosPersona[1]);
        dia = Integer.valueOf(datosPersona[2]);
        mes = Integer.valueOf(datosPersona[3]);
        año = Integer.valueOf(datosPersona[4]);
        // Crear nueva persona a partir de los datos.
        nuevaPersona = new Persona(dia,mes,año,nombre,estadoCivil);
        return nuevaPersona;
    }
    }
