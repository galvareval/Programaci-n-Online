import java.util.ArrayList;
import java.util.Iterator;
import java.util.Calendar;
/**
 * Clase que represnta una lista de personas
 * 
 * @author (Gianfranco Álvarez) 
 * @version (01_17_02_2022)
 */
public class ListaPersonas
{
    // Atributo lista de objetos Persona..
    private ArrayList<Persona> listaPersonas;
    
    /**
     * Constructor de objetos de la clase ListaPersonas.
     */
    public ListaPersonas()
    {
        // Inicializar la lista.
        listaPersonas = new ArrayList<Persona>();
    }
    
    /**
     * Método que devuelve cuantas personas estas divorciadas mediente iterator.
     * 
     * @return Devuelve el número de personas divorciadas.
     */
    public int cuantosDivorciados()
    {
        // Declarar iterador
        Iterator<Persona> it;
        it = listaPersonas.iterator();
        // Declarar e inicializar contador
        int contadorDivcorciados;
        contadorDivcorciados = 0;
        // Recorrer la lista mediante el iterador, si es divorciado sumar 1 al contador.
        while(it.hasNext())
        {
            if(it.next().getEstadoToString().equals("DIVORCIADO"))
                contadorDivcorciados++;
        }
        return contadorDivcorciados;
    }
    
    /**
     * Método para añadir una nueva persona a la lista mediante parámetro.
     * 
     * @param persona Parámetro para pasar la persona a añadir.
     */
    public void addPersona(Persona persona)
    {
        if (persona != null)
            listaPersonas.add(persona);
        else
            System.out.println("Parámetro incorrecto, persona no añadida.");
    }
    
    /**
     * Método que devuelve un String informacion de las personas de la lista.
     * 
     * @return Devuelve String con los datos de las personas de la lista.
     */
    public String toString ()
    {
        // Declarar e incialiazr var para almacenar el resultado.
        String resultado = "";
        // Recorrer la lista mediante For
        for (Persona per : listaPersonas)
        // Almacenar en resultado la representación String de cada persona
            resultado += per.toString();
        return resultado;
    }
    
    /**
     * Método para imprimir por pantalla las representación textual 
     * de todas las personas de la lista.
     * 
     */
    public void printPersonas()
    {
        System.out.println(toString());
    }
    
    /**
     * Método que borra de la lista las personas solteras.
     * Devuelve un Arraylist con estas personas.
     * 
     * @return Devuelve un Arraylist con las personas solteras.
     */
    public ArrayList<Persona> borrarSolteros()
    {
        // Nueva lista para almacenar los solteros.
        ArrayList<Persona> listaSolteros = new ArrayList<Persona>();
        // Declarar iterador
        Iterator<Persona> it;
        it = listaPersonas.iterator();
        // Recorrer la lista mediante el iterador, 
        //si es soltero añadir a la nueva lista de solteros y borrar de la lista.
        while(it.hasNext())
        {
            Persona per = it.next();
            if(per.getEstadoToString().equals("SOLTERO"))
                {
                    listaSolteros.add(per);
                    it.remove();
                }
        }
        return listaSolteros;
    }
    
    /**
     * Método que devuelve la persona más joven de la lista.
     * Si está vacia devuelve null.
     * 
     * @return Devuelve la persona más joven.
     */
    public Persona masJoven()
    {
        // Declarar e inficializar nuevo objeto persona para almacenar la más joven
        Persona perMasJoven = null;
        // Comprobar si la lista esta vacia.
        if (listaPersonas == null || listaPersonas.size() == 0)
            return null;
        else
            {
                // Asignar la persona más joven la primera de la lista.
                perMasJoven = listaPersonas.get(0);
                // Recorrer la lista comparando para encontrar el más joven.
                for (Persona per:listaPersonas)
                {
                    if (perMasJoven.masJovenQue(per) == false)
                        perMasJoven = per;
                }
                return perMasJoven;
            }
    }
    
    /**
     * Método que devuelve la cantidad de personas que cumplen años
     * en el mes indicado como parámetro.
     * 
     * @param mes Para pasar el mes a evaluar.
     * @return Devuelve la cantidad de personas que cumplen años 
     * en el mes pasado por parámetro.
     */
    public int cumplenEnMes(int mes)
    {
        // Declarar en inicializar el contador.
        int contadorCumplenEnMes = 0;
        // Recorrer lista contando las personas cuya mes de nacimiento
        // coincida con el del parámetro - 1, los meses empiezan en 0.
        for (Persona per:listaPersonas)
        {
            if (per.getFechaNacimiento().get(Calendar.MONTH) == mes - 1)
                contadorCumplenEnMes++;
        }
        return contadorCumplenEnMes;
    }
    
    /**
     * Método que devuelve el número total de personas en la lista.
     * 
     * @return Devuelve el número de personas en la lista.
     */
    public int cuantasPersonas()
    {
        return listaPersonas.size();
    }
}
