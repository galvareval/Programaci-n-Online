
/**
 * Tipo enumerado para representar el estado civil de una persona.
 * 
 * @author (Gianfranco Álvarez) 
 * @version (01_17_02_2022)
 */
public enum EstadoCivil
{
    SOLTERO,CASADO,VIUDO,DIVORCIADO;
}

